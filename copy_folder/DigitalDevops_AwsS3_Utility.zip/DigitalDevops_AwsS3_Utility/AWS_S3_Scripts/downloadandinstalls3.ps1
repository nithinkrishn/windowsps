﻿<# 
.SYNOPSIS
Powershell Script to Download s3 browser and create directory structure

.DESCRIPTION
Downloads and install aws s3 browser and create required directory structure

.PARAMETER URLToCheck
$S3ExeLocation - url to download s3 browser
$S3DownloadLocation    - Loaction to download exe
$FolderStructure - List of folders to create with comma separated (eg:C:\S3Store\UNC\Stage,C:\S3Store\UNC\Upload)

.AUTHOR 
Digital DevOps - 07/06/2017
#>
param([string]$S3ExeLocation = "http://netsdk.s3.amazonaws.com/s3browser/6.5.9/s3browser-6-5-9.exe",
      [string]$S3DownloadLocation = "c:\s3.exe",
      [string] $FolderStructure = "C:\S3Store\UNC\Stage,C:\S3Store\UNC\Upload,C:\S3Store\UNC\Download,C:\S3Store\FTP\Stage,C:\S3Store\FTP\Upload,C:\S3Store\FTP\Download")

##Folder Structure
$split_Paths = $FolderStructure.Split(",")
echo ""$split_Paths.Count""
$i = 0
for($i -eq 0;$i -lt $split_Paths.Count;$i++){
New-Item -ItemType Directory -Path $split_Paths[$i] -Force
}

##Download and Install Aws_Powershell Msi
#Invoke-WebRequest $S3ExeLocation -OutFile $S3DownloadLocation
#C:\s3.exe /VERYSILENT /NORESTART