param([string] $ServerName = "LOUWEBWPL337S01",
      [string] $SourcePath = '/HumWeb/docs/go365/www/App_Config',
      [string] $ApplicationName,
      [string] $UserName = 'Humad\kxp0011',
      [string] $Password = '',
      [string] $StagePath  = "C:\S3Store\FTP\Stage",
      [string] $UploadPath  = "C:\S3Store\FTP\Upload", 
      [string] $UploadToS3  = "\S3Upload.ps1",
      [string] $BucketName  = "Production",
      [string] $Module = "WinSCP")

#$Leaf1=$SourcePath.split("/")[-1]
#$Leaf2=$SourcePath.split("/")[-2]
#$Key = $Leaf2 + '_' + $Leaf1
$Key = $ApplicationName + '_' + (Get-Date -Format yyyyMMddTHHmm) 
$DownloadDirectory = $StagePath + '\' + $Key
$ZipFile = $UploadPath + '\' +$Key + '.zip'
echo "Key is $Key"
$Location = $MyInvocation.MyCommand.Path

Function Script-Path(){
  $local:sPath = Split-Path $Location
  Write-host "My script directory is $sPath"
  Push-Location $sPath
  return $sPath
}

function Install-WinscpModule()
{
if (Get-Module -ListAvailable -Name $Module) {
    echo "Module exists"
} 
else {
    echo "Module does not exist,installing module"
    Install-Module -Name $Module -Force
}
}

function Download-FromSource()
{
try{
Import-Module -Name WinSCP
$local:SecureString = ConvertTo-SecureString -AsPlainText $Password -Force
$local:MySecureCreds = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $UserName,$SecureString 
$local:winscpsession = New-WinSCPSession -Credential $MySecureCreds -HostName $ServerName -Protocol Ftp
#$winscpsession = New-WinSCPSession -Credential (Get-Credential) -HostName $ServerName -Protocol Ftp
New-Item $DownloadDirectory -type directory -Force
Sync-WinSCPPath -WinSCPSession $winscpsession -RemotePath $SourcePath -LocalPath $DownloadDirectory -Mode Local 
Remove-WinSCPSession -WinSCPSession $winscpsession -Verbose
}
catch{
        $ErrorMessage = $_.Exception.Message
        echo "error occured $ErrorMessage"
        Exit
        
     }
} 

function ZipAndUpload-ToS3([string] $zipFile,[string] $downloadDirectory,[string] $bucketName)
{
try
{
  ##zip content
  echo "zipping the content to upload to the location $zipFile"
  Add-Type -assembly "system.io.compression.filesystem"
  [io.compression.zipfile]::CreateFromDirectory($downloadDirectory, $zipFile) 
  ##Upload to s3
  echo "uploading the $zipFile to the bucket $bucketName"
  $local:value = Script-Path
  $local:runscript = $value + $UploadToS3
  Invoke-Expression "$runscript -FilePath $zipFile -BucketName $bucketName"
  }
  catch{
     $ErrorMessage = $_.Exception.Message
     echo "error occured $ErrorMessage"
     Exit
  }
}

function Clean-AfterUpload()
{
  echo "Cleaning Directory $DownloadDirectory"
  echo "Cleaning Directory $ZipFile"
  Remove-Item -Path $DownloadDirectory -Recurse -Force -ErrorAction SilentlyContinue
  Remove-Item -Path $ZipFile -Recurse -Force -ErrorAction SilentlyContinue
}
Install-WinscpModule
Download-FromSource
ZipAndUpload-ToS3 -zipFile $ZipFile -downloadDirectory $DownloadDirectory -bucketName $BucketName
Clean-AfterUpload