﻿<# 
.SYNOPSIS
Powershell GenericScript to upload files and folder to AWS s3 bucket

.DESCRIPTION
Download files and folders from Unc path, zip it and upload to aws s3 bucket

.PARAMETER URLToCheck
$SourcePath - source location of package to upload
$BucketName - name of the bucket where packages to be uploaded
$StagePath  - location to download files from source to local
$UploadPath - contains zipped content of $DownloadTo to upload to aws s3
$CleanSource - boolean value, if $true it will clean the $SourcePath, by default it is $false
$UploadToS3 - script to run to upload to s3
$AccessKey - AccessKey of aws s3
$SecretKey - secretkey of aws s3

.AUTHOR 
Digital DevOps - 07/06/2017
#>

param([string] $SourcePath = "\\133.29.6.34\tfsBuild\WS_CommunicationPreferences_1.0.0\141234",
      [string] $key,
      [string] $BucketName,
      [bool] $CleanSource = $false,
      [string] $StagePath = "C:\S3Store\UNC\Stage",
      [string] $UploadPath = "C:\S3Store\UNC\Upload",        
      [string] $UploadToS3 = "\S3Upload.ps1",
      [string] $EndpointUrl = "http://digital_s3store.ecs.humana.com:9020",
      [string] $AccessKey = "digital_s3store",
      [string] $SecretKey = "8gDgGajOrRZsJOd6Y75vJTPytXF9nGuAylcU5miP")
echo "unc source path is $SourcePath"
$Leaf1=$SourcePath.split("\")[-1]
$Leaf2=$SourcePath.split("\")[-2]
$Append = $leaf2 + '_' + $leaf1
$DownloadDirectory = $StagePath + '\' + $Append
$ZipFile = $UploadPath + '\' +$Append + '.zip'
$Location = $MyInvocation.MyCommand.Path

Function Script-Path(){
  $sPath = Split-Path $Location
  Write-host "My script directory is $sPath"
  Push-Location $sPath
  return $sPath
}

if([string]::IsNullOrWhiteSpace($key)) {  
$Key = $Leaf2 + '_' + $Leaf1
}


function Test-ZipFileExists([string] $zipFile)
{
if(Test-Path -Path $zipFile)
{
echo "Destination already have the zip file $zipFile"
exit 1
}
}

function Upload-ToS3([string] $zipFile,[string] $downloadDirectory,[string] $bucketName,[string] $key){
try
 {
  ##zip content
  echo "zipping the content to upload to the location $zipFile"
  Add-Type -assembly "system.io.compression.filesystem"
  [io.compression.zipfile]::CreateFromDirectory($downloadDirectory, $zipFile) 
  ##Upload to s3
  echo "uploading the $zipFile to the bucket $bucketName"
  #Write-S3Object -BucketName $BucketName -Key $Key -File $ZipFile -EndpointUrl $EndpointUrl -AccessKey $AccessKey -SecretKey $SecretKey 
  #& 'C:\Program Files\S3 Browser\s3browser-con.exe' upload DigitalDevops_S3 $ZipFile $BucketName
  $value = Script-Path
  $runscript = $value + $UploadToS3
  Invoke-Expression "$runscript -FilePath $ZipFile -BucketName $BucketName"
 }
catch
 {
  echo "Error occured in uploadtos3 function... Exiting"
  Exit
 }
}


function CleanPackages-AfterUpload([string] $outfile)
{
  echo "cleaning $outfile"
  Remove-Item -Path $outfile -Recurse -Force -ErrorAction SilentlyContinue
   
}



function CleanBuild-AfterUpload()
{
  echo "Cleaning Directory $DownloadDirectory"
  echo "Cleaning Directory $ZipFile"
  Remove-Item -Path $DownloadDirectory -Recurse -Force -ErrorAction SilentlyContinue
  Remove-Item -Path $ZipFile -Recurse -Force -ErrorAction SilentlyContinue
 
 if($CleanSource)
 {
  echo "CleanSource is True"
  echo "unc clean surece source path is $SourcePath"
  Remove-Item -Path $SourcePath -Recurse -ErrorAction SilentlyContinue
  }
 }


function Download-File([string] $sourcePath,[string] $downloadDirectory){
try
 {
  if((Get-Item $sourcePath) -is [System.IO.DirectoryInfo])
  {
   echo "it is directory"
   echo "Key is $Key"
   Robocopy $sourcePath $downloadDirectory *.* /E /SEC /MT /R:1 /W:1 /LOG:c:\Robocopylog.txt
   Upload-ToS3 -ZipFile $ZipFile -DownloadDirectory $DownloadDirectory -BucketName $BucketName -Key $Key
   CleanBuild-AfterUpload
  }
  else 
  {
   echo "it is file"
   $fileName = $sourcePath.split("\")[-1]
   $sourceDirectory = Split-Path -Path $sourcePath
   Robocopy $sourceDirectory $UploadPath $fileName /LEV:1 /E /SEC /MT /R:1 /W:1 /LOG:c:\Robocopylog.txt
   ##Upload to s3
   $files = Get-ChildItem $UploadPath
   for ($i=0; $i -lt $files.Count; $i++) 
   {
   $outfile = $files[$i].FullName 
   echo "out file is $outfile"
   #Write-S3Object -BucketName $bucketName -Key $key -File $outfile -EndpointUrl $EndpointUrl -AccessKey $AccessKey -SecretKey $SecretKey
   #& 'C:\Program Files\S3 Browser\s3browser-con.exe' upload DigitalDevops_S3 $outfile $BucketName
   $value = Script-Path
   $runscript = $value + $UploadToS3
   Invoke-Expression "$runscript -FilePath $outfile -BucketName $BucketName"
   CleanPackages-AfterUpload -outfile $outfile
    
   }
   
  }
 }
 catch
 {
   echo "Error occured in downloadfile function... Exiting"
   Exit
 }
}

Test-ZipFileExists -zipFile $ZipFile
Download-File -sourcePath $SourcePath -downloadDirectory $DownloadDirectory
