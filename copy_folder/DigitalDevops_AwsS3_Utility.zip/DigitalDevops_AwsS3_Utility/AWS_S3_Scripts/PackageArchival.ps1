﻿<# 
.SYNOPSIS
Powershell Script to upload Packages to AWS s3 bucket

.DESCRIPTION
Uploads multiple packages based on the version given

.PARAMETER URLToCheck
$Path - Path before to package name name (eg: \\louappwts1119\Alphapackage)
$PackageName - name of the package (eg: Cxm.Framework)
$version - filter the files based on version (eg:"1.0.0")
Bucketname - name of the bucket to upload the content
$ScriptToRun - This powershell script access the Generic_packagestoupload.ps1 powershell script
$Packages - Pckage download location
$FilterPackages -Location to save the packages after filtering
$CleanSource - if it is $true, cleans the source you provided (by default it is $false)

.AUTHOR 
Digital DevOps - 07/13/2017
#>

param([string] $Path = "\\louappwts1119\Alphapackage",
      [string] $PackageName = "Test123",
      [string] $version = "1.1.0",
      [string] $Bucketname = "Packages",
      [string] $ScriptToRun = "\UNCPath.ps1",
      [string] $Packages = "C:\DownloadPackages",
      [string] $FilterPackages = "C:\filterpackages",
      [bool] $CleanSource = $false)

$PackagePath = $Path + '\' + $PackageName
echo $PackagePath
$Location = $MyInvocation.MyCommand.Path
#$NugetFile = '*' + $version + '*.nupkg'
$NugetFile = $PackageName + '.' + $version +'*.nupkg'

 if(-Not(Get-ChildItem $Packages -force | Select-Object -First 1 | Measure-Object).Count -eq 0)
 {
  echo "folder is not empty"
  Exit
 }

function Script-Path()
 {
   $sPath = Split-Path $Location
   Write-host "My script directory is $sPath"
   Push-Location $sPath
   return $sPath
  }

function get-NugetFiles([string] $packagePath, [string] $packages,[string] $FilterPackages)
 {
  
   Robocopy $packagePath $packages $NugetFile /s  /SEC /MT /R:1 /W:1 /LOG:c:\Robocopylog.txt
   get-childitem $packages -filter *nupkg -recurse | copy-item -Destination $FilterPackages
 }

function uplaod-Files([string] $ScriptToRun,[string] $FilterPackages)
 {
   $value = Script-Path
   $runscript = $value + $scripttorun
   $files = Get-ChildItem $FilterPackages
   for ($i=0; $i -lt $files.Count; $i++) 
   {
    $outfile = $files[$i].FullName 
    echo "Source path is $outfile"
    #Invoke-Expression "$runscript -SourcePath $outfile -BucketName $Bucketname"
     & $runscript -SourcePath $outfile -BucketName $Bucketname -CleanSource $CleanSource -PackagePath $PackagePath -Version $version
   }
 }

function clean-Folders()
 {
   Remove-Item -Path $FilterPackages\* -recurse -Force -ErrorAction SilentlyContinue
   Remove-Item -Path $Packages\* -recurse -Force -ErrorAction SilentlyContinue
   if($CleanSource)
   {
   echo "cleaning packages $PackagePath with version $version"
   Get-ChildItem $PackagePath | Where {$_.PSIsContainer -and ($_ -match "^$version.*")} | Get-ChildItem -Recurse -Force | Remove-Item -Recurse -Force
   }
 }
get-NugetFiles -packagePath $PackagePath -packages $Packages -FilterPackages $FilterPackages
uplaod-Files -ScriptToRun $ScriptToRun -FilterPackages $FilterPackages
clean-Folders