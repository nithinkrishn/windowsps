﻿<# 
.SYNOPSIS
Powershell Script to upload multiple folders to AWS s3 bucket

.DESCRIPTION
Uploads a build definition

.PARAMETER URLToCheck
$Path - Path before to build definition name (eg: \\133.29.6.34\tfsBuild)
$BuildDefinitionName - name of the build definition (eg: Finder_4.1.0)
$BucketName  - Name of the bucket to upload the content
$ScriptToRun - This powershell script access the Generic_Unc_File_upload.ps1 powershell script
$CleanSource - if it is $true, cleans the source you provided (by default it is $false)
.AUTHOR 
Digital DevOps - 07/13/2017
#>

param([string] $Path = "\\133.29.6.34\tfsBuild",
      [string] $BuildDefinitionName = "Z_test",
      [string] $BucketName = "BuildDrop",
      [string] $ScriptToRun = "\UNCPath.ps1",
      [bool] $CleanSource = $false)

$Location = $MyInvocation.MyCommand.Path

Function Script-Path(){
  $sPath = Split-Path $Location
  Write-host "My script directory is $sPath"
  Push-Location $sPath
  return $sPath
}

Function Upload-Folders([string] $BuildDefinitionName,[string] $Path,[string] $ScriptToRun)
{
  $value = Script-Path
  $runscript = $value + $scripttorun
  $BuildPath = $Path + '\' + $BuildDefinitionName
  $folders = Get-ChildItem -Path $BuildPath
  foreach($folder in $folders)
  {
  $folderName = $folder.FullName
  echo "$folderName"
  $childFolders=$folderName.split("\")[-1]
  $keyName = $BuildDefinitionName + '_' + $childFolders
  echo "keyname  is $keyName"
  #Invoke-Expression "$runscript -SourcePath $folderName -key $keyName -BucketName $BucketName"
   & $runscript -SourcePath $folderName -key $keyName -BucketName $BucketName -CleanSource $CleanSource
  }
}
Upload-Folders -BuildDefinitionName $BuildDefinitionName -Path $Path -ScriptToRun $ScriptToRun