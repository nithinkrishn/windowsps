﻿<# 
.SYNOPSIS
Powershell Script to upload files and folder to AWS s3 bucket

.DESCRIPTION
Uploads a single file at atime or upload an entire zip folder

.PARAMETER URLToCheck
$AccountName - Name of s3 browser account name
$FilePath    - Loaction of file to upload
$BucketName - name of the bucket where packages to be uploaded

.AUTHOR 
Digital DevOps - 07/06/2017
#>
param([string] $AccountName = "DigitalDevops_S3", 
      [string] $FilePath, 
      [string] $BucketName)
try
{
echo "This is s3 upload script...................."
& 'C:\Program Files\S3 Browser\s3browser-con.exe' upload $AccountName $FilePath $BucketName
}
catch
{
echo "Error occured in s3upload script ... Exiting"
Exit
}