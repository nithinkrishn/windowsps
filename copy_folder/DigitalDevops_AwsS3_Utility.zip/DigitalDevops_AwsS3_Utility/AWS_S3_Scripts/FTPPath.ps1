﻿<# 
.SYNOPSIS
Powershell Script to upload ftp folder to AWS s3 bucket

.DESCRIPTION
Uploads a ftp folder

.PARAMETER URLToCheck
$SourcePath - source location of folder to upload
$UserName - username to login to ftp
$password - password to login to ftp
$BucketName - name of the bucket where packages to be uploaded
$StagePath  - location to download files from source to local
$UploadToS3 - script to run to upload to s3
$UploadPath - contains zipped content of $DownloadTo to upload to aws s3
$EndpointUrl - Endpoint to connect to s3
$AccessKey - AccessKey of aws s3
$SecretKey - secretkey of aws s3

.AUTHOR 
Digital DevOps - 07/06/2017
#>

#FTP Server Information - SET VARIABLES
param(
[string]$SourcePath = "ftp://LOUWEBWIS26/humweb/docs/humana/ideWS/MemberApplicationService/Backup_7.3",
[string] $UserName    = 'Humad\kxp0011',
[string] $Password    = '',
[string] $StagePath  = "C:\S3Store\FTP\Stage",
[string] $UploadPath  = "C:\S3Store\FTP\Upload", 
[string] $UploadToS3  = "\S3Upload.ps1",
[string] $BucketName  = "Production",
[string] $EndpointUrl = "http://digital_s3store.ecs.humana.com:9020",
[string] $AccessKey   = "digital_s3store",
[string] $SecretKey   = "8gDgGajOrRZsJOd6Y75vJTPytXF9nGuAylcU5miP")

$Leaf1=$SourcePath.split("/")[-1]
$Leaf2=$SourcePath.split("/")[-2]
$Append = $leaf2 + '_' + $leaf1
$DownloadDirectory = $StagePath + '\' + $Append
$ZipFile = $UploadPath + '\' +$Append + '.zip'
$Key = $Leaf2 + '_' + $Leaf1
echo "Key is $Key"
#SET CREDENTIALS
$credentials = new-object System.Net.NetworkCredential($UserName, $Password)
$Location = $MyInvocation.MyCommand.Path

Function Script-Path(){
  $sPath = Split-Path $Location
  Write-host "My script directory is $sPath"
  Push-Location $sPath
  return $sPath
}
 
function Get-FtpDir ($url,$credentials) 
{
  $request = [Net.WebRequest]::Create($url)
  $request.Method = [System.Net.WebRequestMethods+FTP]::ListDirectory
  if ($credentials) { $request.Credentials = $credentials }
  $response = $request.GetResponse()
  $reader = New-Object IO.StreamReader $response.GetResponseStream() 
  $reader.ReadToEnd()
  $reader.Close()
  $response.Close()
}

function Upload-ToS3([string] $zipFile,[string] $downloadDirectory,[string] $bucketName,[string] $key)
{
  ##zip content
  echo "zipping the content to upload to the location $zipFile"
  Add-Type -assembly "system.io.compression.filesystem"
  [io.compression.zipfile]::CreateFromDirectory($downloadDirectory, $zipFile) 
  ##Upload to s3
  echo "uploading the $zipFile to the bucket $bucketName"
  #Write-S3Object -BucketName $BucketName -Key $Key -File $ZipFile -EndpointUrl $EndpointUrl -AccessKey $AccessKey -SecretKey $SecretKey 
  $value = Script-Path
  $runscript = $value + $UploadToS3
  Invoke-Expression "$runscript -FilePath $ZipFile -BucketName $BucketName"
}

function Clean-AfterUpload()
{
  echo "Cleaning Directory $StagePath"
  echo "Cleaning Directory $UploadPath"
  Remove-Item -Path $StagePath\* -Recurse -Force -ErrorAction SilentlyContinue
  Remove-Item -Path $UploadPath\* -Recurse -Force -ErrorAction SilentlyContinue
}
 
function Download-FromFtp([string] $SourcePath,[string] $DownloadDirectory)
{
  $Allfiles=Get-FTPDir -url $SourcePath -credentials $credentials
  $files = ($Allfiles -split "`r`n")
  $files 
  $webclient = New-Object System.Net.WebClient 
  $webclient.Credentials = New-Object System.Net.NetworkCredential($UserName,$Password) 
  $counter = 0
  New-Item -Path $DownloadDirectory -type directory -Force -ErrorAction SilentlyContinue
  foreach ($file in ($files | where {$_ -like "*.*"}))
  {
   $source=$SourcePath + '/' + $file 
   echo "ftp location is $SourcePath" 
   $destination = $DownloadDirectory + '\' + $file 
   echo "....................... this is destination $destination.................................."
   $webclient.DownloadFile($source, $destination)
   #PRINT FILE NAME AND COUNTER
   $counter++
   $counter
   $source
  }
 }
  Download-FromFtp -SourcePath $SourcePath -DownloadDirectory $DownloadDirectory 
  Upload-ToS3 -zipFile $ZipFile -downloadDirectory $DownloadDirectory -bucketName $BucketName -key $Key
  Clean-AfterUpload