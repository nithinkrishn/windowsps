#Introduction 
Powershell scripts to upload content to AWS S3 bucket
#How To Use
 ##List of scripts we have:
 1. downloadandinstalls3.ps1 - This script downloads and install aws tools for windows powershell and creates required directory structure
 2. BuildDropArchival.ps1    - This script downloads  the required folder or file from UNC Path we provided, zip it and uploads to the AWS S3 bucket "BuildDrop"
 3. PackageArchival.ps1      - This script downloads required packages based on version we provided from UNC Path we provided, zip it and uploads to the AWS S3 bucket "Packages"
 4. UNCPath.ps1              - This script access the two scripts BuildDropArchival.ps1 and PackageArchival.ps1 based on the input we provide, if we give folder name as a path it access "BuildDropArchival.ps1" script and get all the folders and uploads to bucket, if we give filename as a path it access "PackageArchival.ps1" script and get all the Nuget files based on version and uploads to bucket
 5. FTPPath.ps1              - This script downloads required folder from FTP Path we provided, zip it and uploads to the AWS S3 bucket "Production"
 6. S3Upload.ps1             - This is the script invoked by other scripts to upload to S3 bucket.
 
 Note:Further more detailed information found in each scripts manual

##Location of the scripts
 Execute these scripts from Lousspwts160 from the location C:\Users\KXP0011\S3-Configuration