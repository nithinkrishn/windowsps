﻿<# 
.SYNOPSIS
Powershell Script to upload package to AWS s3 bucket

.DESCRIPTION
Uploads a single package at atime 

.PARAMETER 
$SourcePath - source location of package to upload
$BucketName - name of the bucket where packages to be uploaded
$PackagesUpload  - location to download package from sourece to local
$EndpointUrl - url of aws s3
$AccessKey - AccessKey of aws s3
$SecretKey - secretkey of aws s3

.AUTHOR 
Digital DevOps - 07/06/2017
#>

param([string] $SourcePath = "\\louappwts1119\Alphapackage\Web.Areas.Go365Tools\2.6.1-alpha00001\Web.Areas.Go365Tools.2.6.1-alpha00001.nupkg",
      [string] $PackagesUpload = "C:\Package\Upload",
      [string] $Packages = "C:\DownloadPackages",
      [string] $BucketName = "Packages", 
      [bool] $CleanSource = $false,
      [string] $FileName = "*.*",
      [string] $EndpointUrl = "http://digital_s3store.ecs.humana.com:9020",
      [string] $AccessKey = "digital_s3store",
      [string] $SecretKey = "8gDgGajOrRZsJOd6Y75vJTPytXF9nGuAylcU5miP")

$key=$SourcePath.split("\")[-1]
echo "key is $key"

if($CleanSource)
{
Remove-Item -Path $SourcePath -Recurse -ErrorAction SilentlyContinue
}

function Get-PackageContent([string] $sourcePath,[string] $packagesUpload)
{
$sourceDirectory = Split-Path -Path $sourcePath
echo "downloading package to $packagesUpload"
Robocopy $sourceDirectory $packagesUpload  $key /s  /SEC /R:1 /W:1 /LOG:c:\Robocopylog.txt 
}

function Packages-ToUplaod([string] $packagesUpload,[string] $bucketName,[string] $key)
{
##Upload to s3
echo "writing $key to s3 bucket $bucketName"
$files = Get-ChildItem $packagesUpload
for ($i=0; $i -lt $files.Count; $i++) {
    $outfile = $files[$i].FullName 
    echo "out file is $outfile"
Write-S3Object -BucketName $bucketName -Key $key -File $outfile -EndpointUrl $EndpointUrl -AccessKey $AccessKey -SecretKey $SecretKey
    }
}


function Clean-Packages([string] $packages, [string] $packagesUpload)
{
echo "cleaning packages"
$clean = $packages + '\' + '*'
$cleanUpload = $packagesUpload + '\' + '*'
Remove-Item $clean, $cleanUpload  -recurse -Force -ErrorAction SilentlyContinue
}
Get-PackageContent -sourcePath $SourcePath -packagesUpload $PackagesUpload
Packages-ToUplaod -packagesUpload $PackagesUpload -bucketName $BucketName -key $key
Clean-Packages -packages $packages -packagesUpload $PackagesUpload