﻿<# 
.SYNOPSIS
Powershell Script to upload files to AWS s3 bucket

.DESCRIPTION
Uploads a single file at atime or upload entire folder

.PARAMETER 
$SourcePath - source location of package to upload
$BucketName - name of the bucket where packages to be uploaded
$DownloadTo  - location to download files from source to local
$UploadFrom - contains zipped content of $DownloadTo to upload to aws s3
$CleanSource - boolean value, if $true it will clean the $SourcePath, by default it is $false
$AccessKey - AccessKey of aws s3
$SecretKey - secretkey of aws s3

.AUTHOR 
Digital DevOps - 07/06/2017
#>

param([string] $SourcePath = "\\louwebwts131\TfsBuild\CodedUI_Integrated\20161212.1\Area\caregiver.dll",
      [string] $DownloadTo = "C:\Build\Stage",
      [string] $UploadFrom = "C:\Build\Upload", 
      [string] $BucketName = "BuildDrop",
      [bool] $CleanSource = $false,
      [string] $EndpointUrl = "http://digital_s3store.ecs.humana.com:9020",
      [string] $AccessKey = "digital_s3store",
      [string] $SecretKey = "8gDgGajOrRZsJOd6Y75vJTPytXF9nGuAylcU5miP")

$Leaf1=$SourcePath.split("\")[-1]
$Leaf2=$SourcePath.split("\")[-2]
$Append = $leaf2 + '_' + $leaf1
$DownloadDirectory = $DownloadTo + '\' + $Append
$ZipFile = $UploadFrom + '\' +$Append + '.zip'
$Key = $Leaf2 + '_' + $Leaf1


if($CleanSource)
{
Remove-Item -Path $SourcePath -Recurse -ErrorAction SilentlyContinue
}

function Test-ZipFileExists([string] $zipFile)
{
echo "Cleaning Folders"
if(Test-Path -Path $zipFile)
{
echo "Destination already have the zip file $zipFile"
exit 1
}
}

function Upload-ToS3([string] $zipFile,[string] $downloadDirectory,[string] $bucketName,[string] $key){
##zip content
echo "zipping the content to upload to the location $zipFile"
Add-Type -assembly "system.io.compression.filesystem"

[io.compression.zipfile]::CreateFromDirectory($downloadDirectory, $zipFile) 

##Upload to s3
echo "uploading the $zipFile to the bucket $bucketName"
Write-S3Object -BucketName $BucketName -Key $Key -File $ZipFile -EndpointUrl $EndpointUrl -AccessKey $AccessKey -SecretKey $SecretKey 
}


function Download-File([string] $sourcePath,[string] $downloadDirectory){

if((Get-Item $sourcePath) -is [System.IO.DirectoryInfo])
{
  echo "it is directory"
  echo "Key is $Key"
Robocopy $sourcePath $downloadDirectory *.* /E /SEC /R:1 /W:1 /LOG:c:\Robocopylog.txt
Upload-ToS3 -ZipFile $ZipFile -DownloadDirectory $DownloadDirectory -BucketName $BucketName -Key $Key
}

else {
echo "it is file"
$fileName = $sourcePath.split("\")[-1]
$sourceDirectory = Split-Path -Path $sourcePath
Robocopy $sourceDirectory $UploadFrom $fileName /LEV:1 /E /SEC /R:1 /W:1 /LOG:c:\Robocopylog.txt
##Upload to s3
$fn= $UploadFrom + '\' + $fileName
echo "Key is $fileName"
echo "uploading the $fn to the bucket $BucketName"
Write-S3Object -BucketName $BucketName -Key $fileName -File $fn -EndpointUrl $EndpointUrl -AccessKey $AccessKey -SecretKey $SecretKey
}
}

function Clean-AfterUpload()
{
echo "Cleaning Directory $DownloadTo"
echo "Cleaning Directory $UploadFrom"
Remove-Item -Path $DownloadTo\* -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -Path $UploadFrom\* -Recurse -Force -ErrorAction SilentlyContinue
}

Test-ZipFileExists -zipFile $ZipFile
Download-File -sourcePath $SourcePath -downloadDirectory $DownloadDirectory
Clean-AfterUpload