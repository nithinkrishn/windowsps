<# 
.SYNOPSIS
Powershell Script to upload Packages to AWS s3 bucket

.DESCRIPTION
Uploads multiple packages based on the version given

.PARAMETER URLToCheck
$Path - Path before to package name name (eg: \\louappwts1119\Alphapackage)
$PackageName - name of the package (eg: Cxm.Framework)
$ScriptToRun - This powershell script access the Generic_packagestoupload.ps1 powershell script
$Packages - Pckage download location
$FilterPackages -Location to save the packages after filtering

.AUTHOR 
Digital DevOps - 07/13/2017
#>

param([string] $Path = "\\louappwts1119\Alphapackage",
      [string] $PackageName = "Cxm.Framework",
      [string] $version = "8.2.0",
      [string] $ScriptToRun = "\Generic_packagestoupload.ps1",
      [string] $Packages = "C:\DownloadPackages",
      [string] $FilterPackages = "C:\filterpackages")

$PackagePath = $Path + '\' + $PackageName
echo $PackagePath
$Location = $MyInvocation.MyCommand.Path
$NugetFile = '*' + $version + '*.nupkg'

function Script-Path()
 {
   $sPath = Split-Path $Location
   Write-host "My script directory is $sPath"
   Push-Location $sPath
   return $sPath
  }

function get-NugetFiles([string] $packagePath, [string] $packages,[string] $FilterPackages)
 {
   Robocopy $packagePath $packages  $NugetFile /s  /SEC /R:1 /W:1 /LOG:c:\Robocopylog.txt 
   get-childitem $packages -filter *nupkg -recurse | copy-item -Destination $FilterPackages
 }

function uplaod-Files([string] $ScriptToRun,[string] $FilterPackages)
 {
   $value = Script-Path
   $runscript = $value + $scripttorun
   $files = Get-ChildItem $FilterPackages
   for ($i=0; $i -lt $files.Count; $i++) 
   {
    $outfile = $files[$i].FullName 
    echo "Source path is $outfile"
    Invoke-Expression "$runscript -SourcePath $outfile"
   }
 }

function clean-Folders()
 {
   Remove-Item -Path $FilterPackages\* -recurse -Force -ErrorAction SilentlyContinue
 }
get-NugetFiles -packagePath $PackagePath -packages $Packages -FilterPackages $FilterPackages
uplaod-Files -ScriptToRun $ScriptToRun -FilterPackages $FilterPackages
clean-Folders