<# 
.SYNOPSIS
Prerequisites for AWS S3

.DESCRIPTION
Script used to Create required folder structure,download and install aws_powershell msi and configure ftp

.PARAMETER
$AwsMsiLocation - Url of msi to download
$MsiDownloadLocation - download location in local
$FolderStructure - folder structure to create (Give comma seperated values)

.AUTHOR 
Digital DevOps - 07/06/2017
#>

param([string]$AwsMsiLocation = "https://sdk-for-net.amazonwebservices.com/latest/AWSToolsAndSDKForNet.msi",
      [string] $MsiDownloadLocation = "C:\aws.msi",
      [string] $FolderStructure = "C:\Build\Stage,C:\Build\Upload,C:\Build\Download,C:\Package\Upload,C:\Package\Download,C:\Production\Stage,C:\Production\Upload,C:\Production\Download"
)

##Folder Structure
$split_Paths = $FolderStructure.Split(",")
echo ""$split_Paths.Count""
$i = 0
for($i -eq 0;$i -lt $split_Paths.Count;$i++){
New-Item -ItemType Directory -Path $split_Paths[$i] -Force
}

##Download and Install Aws_Powershell Msi
Invoke-WebRequest $AwsMsiLocation -OutFile $MsiDownloadLocation 
C:\Windows\System32\msiexec.exe /i  $MsiDownloadLocation /passive ACCEPT=YES /norestart 

## Ensure Ftp is configured
$Script:windowsFeatureName = "Web-Server"
Install-WindowsFeature -Name $Script:windowsFeatureName -IncludeAllSubFeature -IncludeManagementTools