<# 
.SYNOPSIS
Powershell Script to upload ftp folder to AWS s3 bucket

.DESCRIPTION
Uploads a ftp folder

.PARAMETER URLToCheck
$Ftp - source location of folder to upload
$UserName - username to login to ftp
$password - password to login to ftp
$BucketName - name of the bucket where packages to be uploaded
$DownloadTo  - location to download files from source to local
$UploadFrom - contains zipped content of $DownloadTo to upload to aws s3
$EndpointUrl - Endpoint to connect to s3
$AccessKey - AccessKey of aws s3
$SecretKey - secretkey of aws s3

.AUTHOR 
Digital DevOps - 07/06/2017
#>

#FTP Server Information - SET VARIABLES
param(
[string]$Ftp = "ftp://LOUWEBWIS26/humweb/docs/humana/ideWS/MemberApplicationService/Backup_7.3",
[string] $UserName    = 'Humad\kxp0011',
[string] $Password    = '',
[string] $DownloadTo  = "C:\Production\Stage",
[string] $UploadFrom  = "C:\Production\upload", 
[string] $BucketName  = "Production",
[string] $EndpointUrl = "http://digital_s3store.ecs.humana.com:9020",
[string] $AccessKey   = "digital_s3store",
[string] $SecretKey   = "8gDgGajOrRZsJOd6Y75vJTPytXF9nGuAylcU5miP")

$Leaf1=$Ftp.split("/")[-1]
$Leaf2=$Ftp.split("/")[-2]
$Append = $leaf2 + '_' + $leaf1
$DownloadDirectory = $DownloadTo + '\' + $Append
$ZipFile = $UploadFrom + '\' +$Append + '.zip'
$Key = $Leaf2 + '_' + $Leaf1
echo "Key is $Key"
#SET CREDENTIALS
$credentials = new-object System.Net.NetworkCredential($UserName, $Password)
 
function Get-FtpDir ($url,$credentials) 
{
  $request = [Net.WebRequest]::Create($url)
  $request.Method = [System.Net.WebRequestMethods+FTP]::ListDirectory
  if ($credentials) { $request.Credentials = $credentials }
  $response = $request.GetResponse()
  $reader = New-Object IO.StreamReader $response.GetResponseStream() 
  $reader.ReadToEnd()
  $reader.Close()
  $response.Close()
}

function Upload-ToS3([string] $zipFile,[string] $downloadDirectory,[string] $bucketName,[string] $key)
{
  ##zip content
  echo "zipping the content to upload to the location $zipFile"
  Add-Type -assembly "system.io.compression.filesystem"
  [io.compression.zipfile]::CreateFromDirectory($downloadDirectory, $zipFile) 
  ##Upload to s3
  echo "uploading the $zipFile to the bucket $bucketName"
  Write-S3Object -BucketName $BucketName -Key $Key -File $ZipFile -EndpointUrl $EndpointUrl -AccessKey $AccessKey -SecretKey $SecretKey 
}

function Clean-AfterUpload()
{
  echo "Cleaning Directory $DownloadTo"
  echo "Cleaning Directory $UploadFrom"
  Remove-Item -Path $DownloadTo\* -Recurse -Force -ErrorAction SilentlyContinue
  Remove-Item -Path $UploadFrom\* -Recurse -Force -ErrorAction SilentlyContinue
}
 
function Download-FromFtp([string] $Ftp,[string] $DownloadDirectory)
{
  $Allfiles=Get-FTPDir -url $Ftp -credentials $credentials
  $files = ($Allfiles -split "`r`n")
  $files 
  $webclient = New-Object System.Net.WebClient 
  $webclient.Credentials = New-Object System.Net.NetworkCredential($UserName,$Password) 
  $counter = 0
  New-Item -Path $DownloadDirectory -type directory -Force -ErrorAction SilentlyContinue
  foreach ($file in ($files | where {$_ -like "*.*"}))
  {
   $source=$Ftp + '/' + $file 
   echo "ftp location is $Ftp" 
   $destination = $DownloadDirectory + '\' + $file 
   echo "....................... this is destination $destination.................................."
   $webclient.DownloadFile($source, $destination)
   #PRINT FILE NAME AND COUNTER
   $counter++
   $counter
   $source
  }
 }
  Download-FromFtp -Ftp $Ftp -DownloadDirectory $DownloadDirectory 
  Upload-ToS3 -zipFile $ZipFile -downloadDirectory $DownloadDirectory -bucketName $BucketName -key $Key
  Clean-AfterUpload