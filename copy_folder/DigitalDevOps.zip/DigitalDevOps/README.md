This code base is tested on __Windows 2012 Server edition only.

DSC        - Powershell dsc code that will converted to puppet library.

IISWebsite - Puppet code to create IIS Website & firewall Ports

PowerShell -  Powershell DSC code base for puppet.

Reboot     - Puppet code to reboot the server post installing WMF 5.0

setupenvironment.ps1 - Initial powershell script that will install puppet agent

Stdlib     - Library files for puppet development.

Choco      - This is custom dsc module to install chcocolatey and to install chocolatey packages

Customdsc  - This is custom dsc module to perform system healthcheck.
