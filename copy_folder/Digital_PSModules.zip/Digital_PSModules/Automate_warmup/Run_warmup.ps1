﻿param([string] $TargetScript = './secured.ps1',[string] $usern = 'lousspwts\ddevops',[string] $pass = 'dgtldevops') 
#$MyCredential = Get-Credential
$scriptpath = $MyInvocation.MyCommand.Path
$hash = @{
    lousspwts268 = '133.8.3.44'
    lousspwts269 = '133.8.3.48'
    lousspwts270 = '133.8.3.52'
    lousspwts271 = '133.8.3.56'
    lousspwts272 = '133.8.3.120'
    lousspwts273 = '133.8.2.222'
}

 Function Module-path(){
 
    $dir = Split-Path $scriptpath
    Write-host "My script directory is $dir"
    Push-Location $dir
 
 }


 Function Get-ScriptBlock()
 {
    Param([string] $ScriptOrPath) 

    # If content ends with .ps1 then script 
    if($ScriptOrPath.EndsWith(".ps1"))
    {
        $ScriptBlock = [scriptblock]::Create((Get-content  -Path $ScriptOrPath -Raw)) 
    }
    else
    {
        $ScriptBlock = [scriptblock]::Create($ScriptOrPath) 
    }
    return $ScriptBlock 
}

  Function Execute-Script()
  { 
    Module-path
    foreach ($h in $hash.GetEnumerator()) {
    $ScriptBlock = Get-ScriptBlock -ScriptOrPath $TargetScript
    $SecureString = ConvertTo-SecureString $pass -AsPlainText -Force
    $Credentials = New-Object System.Management.Automation.PSCredential($usern,$SecureString)
    $job = Invoke-Command -ComputerName $h.Name  -ScriptBlock $ScriptBlock -ArgumentList $h.Value -Credential $Credentials -AsJob
    $job | Get-Job | Wait-Job
    Get-Job | Receive-Job
    }
  }
  Execute-Script

