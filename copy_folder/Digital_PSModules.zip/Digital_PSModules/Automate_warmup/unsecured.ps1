param([string]$ipAddress, [string] $urll = 'www.humana.com',[bool]  $isHttps = $true, [string]$path = "medicare,individual-and-family", [int]$users = 3, [int]$maxTimeout = 10, [string]$filesToClose = 'C:\Windows\System32\drivers\etc\hosts' )
Import-Module 'C:\Program Files\WindowsPowerShell\Modules\Warmup'

 #Determine the protocol
 $protocol = "http://"
 if($isHttps){$protocol = "https://"}

echo $protocol

#Build Url
$url = $protocol + $urll  
echo $url

#Close-OpenFile -filesToClose $filesToClose -ErrorAction SilentlyContinue
HostFileEntry -ipAddress $ipAddress -url $urll
CheckStatusWithTimeout  -url $url -maxTimeout $maxTimeout
HitPagesForUsers -url $url -paths $path -users $users