<# 
.SYNOPSIS
    Access Machine Group from TFS 

.DESCRIPTION
    Module to Access machine group from TFS. Machine FQDN & Credentials 

.LAST MODIFIED 
    Jul 25, 2016
#>

# Constants 
Set-Variable PSCredentialKeyConstant -Option ReadOnly -Value "PSCredentials" -Scope Global

# Import dlls with Direct Dependencies 
Import-module "Microsoft.TeamFoundation.DistributedTask.Task.Internal"
Import-module "Microsoft.TeamFoundation.DistributedTask.Task.Common"
Import-module "Microsoft.TeamFoundation.DistributedTask.Task.DevTestLabs"
Import-Module "Microsoft.TeamFoundation.DistributedTask.Task.Deployment.Internal"
        
# Machine filter - Tags         
$machineFilter = $machineNames

# Getting resource tag key name for corresponding tag
$resourceFQDNKeyName = Get-ResourceFQDNTagKey
$resourceWinRMHttpPortKeyName = Get-ResourceHttpTagKey
$resourceWinRMHttpsPortKeyName = Get-ResourceHttpsTagKey
      
# Constants 
$useHttpProtocolOption = '-UseHttp'
$useHttpsProtocolOption = ''

$doSkipCACheckOption = '-SkipCACheck'
$doNotSkipCACheckOption = ''
$ErrorActionPreference = 'Stop'
$deploymentOperation = 'Deployment'

$envOperationStatus = "Passed"
$telemetrySet = $false

# Get Build Agent version by checking 
$isAgentVersion97 = ((Get-Command Register-Environment).Parameters.ContainsKey("Persist"));

$telemetryCodes = 
@{
    "PREREQ_NoWinRMHTTP_Port" = "PREREQ001";
    "PREREQ_NoWinRMHTTPSPort" = "PREREQ002";
    "PREREQ_NoResources" = "PREREQ003";
    "PREREQ_NoOutputVariableForSelectActionInAzureRG" = "PREREQ004";
    "UNKNOWNPREDEP_Error" = "UNKNOWNPREDEP001";
    "DEPLOYMENT_Failed" = "DEP001";
    "PREREQ_InvalidFilePath" = "PREREQ_InvalidFilePath";
    "DEPLOYMENT_PerformActionFailed" = "DEPLOYMENT_PerformActionFailed"
 }

 <# 
    .SYNOPSIS
    Get Machine Names, PSCredential Instance from Machine Group  

    .DESCRIPTION
    This function is capable of accesing machine names (FQDN) & Credential configured for a TFS Machine Group. 
        
    .RETURNS
    Returns a Hastable Objec
    Key "PSCredentials" contains PSCredential instance to the machine group
    Each matching machine group, will be assigned a key value pair of "MachineName & FQDN" 

    .LAST MODIFIED 
    Jul 22, 2016
#>
Function Get-MachineGroupProperties()
{
    Param([string] $environmentName, [string] $MachineTags)
                 
    try
    {
        # Establish Connection to TFS 
        $connection = Get-VssConnection -TaskContext $distributedTaskContext

        # Filter & Read Machine Group Properties 
        Write-Verbose "Starting Register-Environment cmdlet call for environment : $environmentName with filter $machineFilter" -Verbose           
        $environment = Register-Environment -EnvironmentName $environmentName -EnvironmentSpecification $environmentName -WinRmProtocol $protocol -TestCertificate ($testCertificate -eq "true") -Connection $connection -TaskContext $distributedTaskContext -ResourceFilter $machineFilter -UserName $adminUserName -Password $adminPassword
        Write-Verbose "Completed Register-Environment cmdlet call for environment : $environmentName" -Verbose

        Write-Verbose "Starting Get-EnvironmentResources cmdlet call on environment name: $environmentName" -Verbose
            
        if($isAgentVersion97)
        {
            $resources = Get-EnvironmentResources -Environment $environment
        }
        else
        {
            $resources = Get-EnvironmentResources -EnvironmentName $environmentName -TaskContext $distributedTaskContext 
        }
        
        if ($resources.Count -eq 0)
        {
            Write-TaskSpecificTelemetry "PREREQ_NoResources"
            throw (Get-LocalizedString -Key "No machine exists under environment: '{0}' for deployment" -ArgumentList $environmentName)
        }

        $resourcesPropertyBag = Get-ResourcesProperties -resources $resources
    }
    catch
    {
        if(-not $telemetrySet)
        {
            Write-TaskSpecificTelemetry "UNKNOWNPREDEP_Error"
        }
        throw
    }

    # Create Empty Hastable for returing the properties 
    $MachineGroupProperties = @{}

    # Assign PS Credential to PSCredentials. One time operation since Machine Groups, group machine under same identity.         
    foreach($resource in $resources)
    {
        $resourceProperties = $resourcesPropertyBag.Item($resource.Id)
        # Assign the PS Credential Object Only once, since MachineGroups group machine under same identity. 
        if(!($MachineGroupProperties.ContainsKey($PSCredentialKeyConstant)))
        {
            $MachineGroupProperties.Add($PSCredentialKeyConstant , $resourceProperties.credential)
        }            
        # Add Machine Name & FQDN 
        $MachineGroupProperties.Add($resourceProperties.displayName, $resourceProperties.fqdn)
    }

    # Retrun the properites to be used in the tasks 
    return $MachineGroupProperties
}

 Function ThrowError
{
    param([string]$errorMessage)
    
        $readmelink = "http://tfs.humana.com:8080/tfs/DefaultCollection2/DevOps/Automation/_git/TFS_Task_EnvironmentVariable?path=%2FREADME.md&version=GBmaster&_a=contents"
        $helpMessage = (Get-LocalizedString -Key "For more info please refer to {0}" -ArgumentList $readmelink)
        throw "$errorMessage $helpMessage"
}

Function Write-Telemetry
{
  [CmdletBinding()]
  param(
    [Parameter(Mandatory=$True,Position=1)]
    [string]$codeKey,

    [Parameter(Mandatory=$True,Position=2)]
    [string]$taskId
    )
  
  if($telemetrySet)
  {
    return
  }

  $code = $telemetryCodes[$codeKey]
  $telemetryString = "##vso[task.logissue type=error;code=" + $code + ";TaskId=" + $taskId + ";]"
  Write-Host $telemetryString
  $telemetrySet = $true
}

function Write-TaskSpecificTelemetry
{
    param(
      [string]$codeKey
      )
    Write-Telemetry "$codeKey" "34ff7bea-4c42-418d-ae53-e881080d517c"
}

function Get-ResourceWinRmConfig
{
    param
    (
        [string]$resourceName,
        [int]$resourceId
    )

    $resourceProperties = @{}

    $winrmPortToUse = ''
    $protocolToUse = ''

    if(-not $isAgentVersion97)
    {
        Write-Verbose "Starting Get-Environment cmdlet call on environment name: $environmentName" -Verbose
        $environment = Get-Environment -environmentName $environmentName -TaskContext $distributedTaskContext
        Write-Verbose "Completed Get-Environment cmdlet call on environment name: $environmentName" -Verbose
    }
    
    if($protocol -eq "HTTPS")
    {
        $protocolToUse = $useHttpsProtocolOption
    
        Write-Verbose "Starting Get-EnvironmentProperty cmdlet call on environment name: $environmentName with resource id: $resourceId(Name : $resourceName) and key: $resourceWinRMHttpsPortKeyName" -Verbose
        if($isAgentVersion97)
        {
            $winrmPortToUse = Get-EnvironmentProperty -Environment $environment -Key $resourceWinRMHttpsPortKeyName -ResourceId $resourceId
        }
        else
        {
            $winrmPortToUse = Get-EnvironmentProperty -EnvironmentName $environmentName -Key $resourceWinRMHttpsPortKeyName -TaskContext $distributedTaskContext -ResourceId $resourceId
        }
        Write-Verbose "Completed Get-EnvironmentProperty cmdlet call on environment name: $environmentName with resource id: $resourceId (Name : $resourceName) and key: $resourceWinRMHttpsPortKeyName" -Verbose
    
        if([string]::IsNullOrWhiteSpace($winrmPortToUse))
        {
            Write-TaskSpecificTelemetry "PREREQ_NoWinRMHTTPSPort"
            throw(Get-LocalizedString -Key "{0} port was not provided for resource '{1}'" -ArgumentList "WinRM HTTPS", $resourceName)
        }
    }
    elseif($protocol -eq "HTTP")
    {
        $protocolToUse = $useHttpProtocolOption
        
        Write-Verbose "Starting Get-EnvironmentProperty cmdlet call on environment name: $environmentName with resource id: $resourceId(Name : $resourceName) and key: $resourceWinRMHttpPortKeyName" -Verbose
        if($isAgentVersion97)
        {
            $winrmPortToUse = Get-EnvironmentProperty -Environment $environment -Key $resourceWinRMHttpPortKeyName -ResourceId $resourceId
        }
        else
        {
            $winrmPortToUse = Get-EnvironmentProperty -EnvironmentName $environmentName -Key $resourceWinRMHttpPortKeyName -TaskContext $distributedTaskContext -ResourceId $resourceId
        }
        Write-Verbose "Completed Get-EnvironmentProperty cmdlet call on environment name: $environmentName with resource id: $resourceId(Name : $resourceName) and key: $resourceWinRMHttpPortKeyName" -Verbose
    
        if([string]::IsNullOrWhiteSpace($winrmPortToUse))
        {
            Write-TaskSpecificTelemetry "PREREQ_NoWinRMHTTPPort"
            throw(Get-LocalizedString -Key "{0} port was not provided for resource '{1}'" -ArgumentList "WinRM HTTP", $resourceName)
        }
    }

    elseif($environment.Provider -ne $null)      #  For standerd environment provider will be null
    {
        Write-Verbose "`t Environment is not standerd environment. Https port has higher precedence" -Verbose

        Write-Verbose "Starting Get-EnvironmentProperty cmdlet call on environment name: $environmentName with resource id: $resourceId(Name : $resourceName) and key: $resourceWinRMHttpsPortKeyName" -Verbose
        if($isAgentVersion97)
        {
            $winrmHttpsPort = Get-EnvironmentProperty -Environment $environment -Key $resourceWinRMHttpsPortKeyName -ResourceId $resourceId
        }
        else
        {
            $winrmHttpsPort = Get-EnvironmentProperty -EnvironmentName $environmentName -Key $resourceWinRMHttpsPortKeyName -TaskContext $distributedTaskContext -ResourceId $resourceId 
        }
        Write-Verbose "Completed Get-EnvironmentProperty cmdlet call on environment name: $environmentName with resource id: $resourceId (Name : $resourceName) and key: $resourceWinRMHttpsPortKeyName" -Verbose

        if ([string]::IsNullOrEmpty($winrmHttpsPort))
        {
               Write-Verbose "`t Resource: $resourceName does not have any winrm https port defined, checking for winrm http port" -Verbose

               Write-Verbose "Starting Get-EnvironmentProperty cmdlet call on environment name: $environmentName with resource id: $resourceId(Name : $resourceName) and key: $resourceWinRMHttpPortKeyName" -Verbose
               if($isAgentVersion97)
               {
                   $winrmHttpPort = Get-EnvironmentProperty -Environment $environment -Key $resourceWinRMHttpPortKeyName -ResourceId $resourceId
               }
               else
               {
                   $winrmHttpPort = Get-EnvironmentProperty -EnvironmentName $environmentName -Key $resourceWinRMHttpPortKeyName -TaskContext $distributedTaskContext -ResourceId $resourceId 
               }
               Write-Verbose "Completed Get-EnvironmentProperty cmdlet call on environment name: $environmentName with resource id: $resourceId(Name : $resourceName) and key: $resourceWinRMHttpPortKeyName" -Verbose

               if ([string]::IsNullOrEmpty($winrmHttpPort))
               {
                   Write-TaskSpecificTelemetry "PREREQ_NoWinRMHTTPPort"
                   throw(Get-LocalizedString -Key "Resource: '{0}' does not have WinRM service configured. Configure WinRM service on the Azure VM Resources. Refer for more details '{1}'" -ArgumentList $resourceName, "http://aka.ms/azuresetup" )
               }
               else
               {
                     # if resource has winrm http port defined
                     $winrmPortToUse = $winrmHttpPort
                     $protocolToUse = $useHttpProtocolOption
               }
        }
        else
        {
              # if resource has winrm https port opened
              $winrmPortToUse = $winrmHttpsPort
              $protocolToUse = $useHttpsProtocolOption
        }
   }
   else
   {
        Write-Verbose "`t Environment is standerd environment. Http port has higher precedence" -Verbose

        Write-Verbose "Starting Get-EnvironmentProperty cmdlet call on environment name: $environmentName with resource id: $resourceId(Name : $resourceName) and key: $resourceWinRMHttpPortKeyName" -Verbose
        if($isAgentVersion97)
        {
            $winrmHttpPort = Get-EnvironmentProperty -Environment $environment -Key $resourceWinRMHttpPortKeyName -ResourceId $resourceId
        }
        else
        {
            $winrmHttpPort = Get-EnvironmentProperty -EnvironmentName $environmentName -Key $resourceWinRMHttpPortKeyName -TaskContext $distributedTaskContext -ResourceId $resourceId 
        }
        Write-Verbose "Completed Get-EnvironmentProperty cmdlet call on environment name: $environmentName with resource id: $resourceId(Name : $resourceName) and key: $resourceWinRMHttpPortKeyName" -Verbose

        if ([string]::IsNullOrEmpty($winrmHttpPort))
        {
               Write-Verbose "`t Resource: $resourceName does not have any winrm http port defined, checking for winrm https port" -Verbose

               Write-Verbose "Starting Get-EnvironmentProperty cmdlet call on environment name: $environmentName with resource id: $resourceId(Name : $resourceName) and key: $resourceWinRMHttpsPortKeyName" -Verbose
               if($isAgentVersion97)
               {
                   $winrmHttpsPort = Get-EnvironmentProperty -Environment $environment -Key $resourceWinRMHttpsPortKeyName -ResourceId $resourceId
               }
               else
               {
                   $winrmHttpsPort = Get-EnvironmentProperty -EnvironmentName $environmentName -Key $resourceWinRMHttpsPortKeyName -TaskContext $distributedTaskContext -ResourceId $resourceId 
               }
               Write-Verbose "Completed Get-EnvironmentProperty cmdlet call on environment name: $environmentName with resource id: $resourceId(Name : $resourceName) and key: $resourceWinRMHttpsPortKeyName" -Verbose

               if ([string]::IsNullOrEmpty($winrmHttpsPort))
               {
                   Write-TaskSpecificTelemetry "PREREQ_NoWinRMHTTPSPort"
                   throw(Get-LocalizedString -Key "Resource: '{0}' does not have WinRM service configured. Configure WinRM service on the Azure VM Resources. Refer for more details '{1}'" -ArgumentList $resourceName, "http://aka.ms/azuresetup" )
               }
               else
               {
                     # if resource has winrm https port defined
                     $winrmPortToUse = $winrmHttpsPort
                     $protocolToUse = $useHttpsProtocolOption
               }
        }
        else
        {
              # if resource has winrm http port opened
              $winrmPortToUse = $winrmHttpPort
              $protocolToUse = $useHttpProtocolOption
        }
   }

    $resourceProperties.protocolOption = $protocolToUse
    $resourceProperties.winrmPort = $winrmPortToUse

    return $resourceProperties;
}


function Get-SkipCACheckOption
{
    [CmdletBinding()]
    Param
    (
        [string]$environmentName
    )

    $skipCACheckOption = $doNotSkipCACheckOption
    $skipCACheckKeyName = Get-SkipCACheckTagKey

    # get skipCACheck option from environment
    Write-Verbose "Starting Get-EnvironmentProperty cmdlet call on environment name: $environmentName with key: $skipCACheckKeyName" -Verbose
    if($isAgentVersion97)
    {
        $skipCACheckBool = Get-EnvironmentProperty -Environment $environment -Key $skipCACheckKeyName
    }
    else
    {
        $skipCACheckBool = Get-EnvironmentProperty -EnvironmentName $environmentName -Key $skipCACheckKeyName -TaskContext $distributedTaskContext 
    }
    Write-Verbose "Completed Get-EnvironmentProperty cmdlet call on environment name: $environmentName with key: $skipCACheckKeyName" -Verbose

    if ($skipCACheckBool -eq "true")
    {
        $skipCACheckOption = $doSkipCACheckOption
    }

    return $skipCACheckOption
}

function Get-ResourcePSCredentials
{
    [CmdletBinding()]
    Param
    (
        [object]$resource
    )

    $machineUserName = $resource.Username
    if([string]::IsNullOrWhiteSpace($machineUserName))
    {
        throw (Get-LocalizedString -Key "Please specify valid username for resource {0}" -ArgumentList $resource.Name)
    }
    Write-Verbose "`t`t Resource Username - $machineUserName" -Verbose

    $machinePassword = ConvertTo-SecureString -AsPlainText $resource.Password -Force
    if([string]::IsNullOrWhiteSpace($machinePassword))
    {
        throw (Get-LocalizedString -Key "Please specify valid password for resource {0}" -ArgumentList $resource.Name)
    }

    $credential = New-Object System.Management.Automation.PSCredential  -ArgumentList $machineUserName, $machinePassword
    return $credential
}

 
function Get-ResourceConnectionDetails
{
    param([object]$resource)

    $resourceProperties = @{}
    $resourceName = $resource.Name
    $resourceId = $resource.Id

    Write-Verbose "Starting Get-EnvironmentProperty cmdlet call on environment name: $environmentName with resource id: $resourceId(Name : $resourceName) and key: $resourceFQDNKeyName" -Verbose
    if($isAgentVersion97)
    {
        $fqdn = Get-EnvironmentProperty -Environment $environment -Key $resourceFQDNKeyName -ResourceId $resourceId
    }
    else
    {
        $fqdn = Get-EnvironmentProperty -EnvironmentName $environmentName -Key $resourceFQDNKeyName -TaskContext $distributedTaskContext -ResourceId $resourceId
    }
    Write-Verbose "Completed Get-EnvironmentProperty cmdlet call on environment name: $environmentName with resource id: $resourceId(Name : $resourceName) and key: $resourceFQDNKeyName" -Verbose

    $winrmconfig = Get-ResourceWinRmConfig -resourceName $resourceName -resourceId $resourceId
    $resourceProperties.fqdn = $fqdn
    $resourceProperties.winrmPort = $winrmconfig.winrmPort
    $resourceProperties.protocolOption = $winrmconfig.protocolOption
    $resourceProperties.credential = Get-ResourcePSCredentials -resource $resource
    $resourceProperties.displayName = $fqdn + ":" + $winrmconfig.winrmPort

    return $resourceProperties
}

function Get-ResourcesProperties
{
    param([object]$resources)

    $skipCACheckOption = Get-SkipCACheckOption -environmentName $environmentName
    [hashtable]$resourcesPropertyBag = @{}

    foreach ($resource in $resources)
    {
        $resourceName = $resource.Name
        $resourceId = $resource.Id
        Write-Verbose "Get Resource properties for $resourceName (ResourceId = $resourceId)" -Verbose
        $resourceProperties = Get-ResourceConnectionDetails -resource $resource
        $resourceProperties.skipCACheckOption = $skipCACheckOption
        $resourcesPropertyBag.add($resourceId, $resourceProperties)
    }

    return $resourcesPropertyBag
}