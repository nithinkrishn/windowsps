param([string]$serverName = 'lousspwts80',[string] $siteName = 'examplsite',[string]$switchPath = "C:\inetpub\wwwroot")

Invoke-Command -ComputerName $serverName  -ScriptBlock {

param([string] $siteName,[string] $switchPath)

if ( (Get-WindowsFeature -name Web-Server,Web-Scripting-Tools).InstallState -eq "Available,Available")
 {
    
   import-module servermanager
   add-windowsfeature Web-Server,Web-Scripting-Tools
 }

 else {
        "Installed.."
 }

  if ( (Get-WindowsFeature -name Web-Server,Web-Scripting-Tools).InstallState -eq "Installed,Installed")
 {
 echo "switching path of site $siteName"
import-module WebAdministration 
Set-ItemProperty "IIS:\Sites\$sitename" -name physicalPath -value "$switchPath"} } -ArgumentList $siteName,$switchPath