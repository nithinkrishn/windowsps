# This is the WarmUp script for both integrated and isolated servers, it has Release definition under DigitalDevops named "Warmup Servers".

### How To Release :
          
	   Warmup Script exists on lousspwts293 machine under C:\Automate_warmup_Integrated, we are executing the script from our release definition.
	   
### Script Arguments :
        
		If script to run is secured, pass 'TargetScript' as './secured', if unsecured give value as './unsecured'.
		'type' is integrated or isolatedHum
		'server' is s01 to s24
		-TargetScript "./secured.ps1" -type 'integrated' -server "S01,S09,S20"	   
	   