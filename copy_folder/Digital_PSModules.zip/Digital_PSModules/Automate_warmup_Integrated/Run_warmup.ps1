﻿param([string] $TargetScript,[string] $type,[string] $server,[string] $page = 'www.humana.com') 
$scriptpath = $MyInvocation.MyCommand.Path
$servers = $server.Split(',')
$count_servers = $servers.Count
echo "Total Integrated Servers are $count_servers"

 Function Module-path(){
 
    $dir = Split-Path $scriptpath
    Write-host "My script directory is $dir"
    Push-Location $dir
 
 }


 Function Get-ScriptBlock()
 {
    Param([string] $ScriptOrPath) 

    # If content ends with .ps1 then script 
    if($ScriptOrPath.EndsWith(".ps1"))
    {
        $ScriptBlock = [scriptblock]::Create((Get-content  -Path $ScriptOrPath -Raw)) 
    }
    else
    {
        $ScriptBlock = [scriptblock]::Create($ScriptOrPath) 
    }
    return $ScriptBlock 
}

  Function Execute-Script()
  { 
    $i = 0 
    Module-path
    $ScriptBlock = Get-ScriptBlock -ScriptOrPath $TargetScript
    for($i -eq 0; $i -lt $count_servers; $i++) {
    echo "-----iteration $i--------"
    $server_value = $type + $servers[$i] + '-' + $page
    #$SecureString = ConvertTo-SecureString $pass -AsPlainText -Force
    #$Credentials = New-Object System.Management.Automation.PSCredential($usern,$SecureString)
    $localjob = Start-Job -ScriptBlock $ScriptBlock -ArgumentList $server_value
    }
     $localjob | Get-Job |Wait-Job
      Get-Job|Receive-Job
      Remove-Job -State Completed 
  }
  Execute-Script 

