﻿Import-Module WebAdministration -ErrorAction Stop

Function Write-Log(){
    Param([string] $LogMessage)
    echo ((Get-Date).ToString() + ": $LogMessage")
}

Function Invoke-CommandAsProcess()
{       
    Param([string] $Cmd) 

    $pinfo = New-Object System.Diagnostics.ProcessStartInfo
    $pinfo.FileName = "$PSHOME\powershell.exe"
    $pinfo.RedirectStandardError = $true
    $pinfo.RedirectStandardOutput = $true
    $pinfo.UseShellExecute = $false
    
    $pinfo.Arguments = "-Command `"$Cmd`""
    $p = New-Object System.Diagnostics.Process
    $p.StartInfo = $pinfo
    $p.Start() | Out-Null
    $p.WaitForExit()
    $standardOutput = $p.StandardOutput.ReadToEnd()
    $standardError = $p.StandardError.ReadToEnd()  
    
    return $standardOutput,$standardError
}

Function Stop-AppPool()
{
    Param([string] $AppPoolName, [boolean] $ForeceKillWorkerProcess = $False)
    
    if($ForeceKillWorkerProcess) 
    {
        $myAppPool = Get-Item "IIS:\Apppools\$AppPoolName"
        # Kill the Worker Processes 
        $myAppPool.workerProcesses.Collection | ForEach-Object {
             Write-Log "Killing Worker Process. Process ID: " + ($_.processId);

             try{                
                Stop-Process $_.processId -Force -ErrorAction Stop
                Write-Log "Worker Process force closed!!"
             }
             catch
             {
                Write-Log "Worker Process terminated by itself... Resuming File Deletion"
             }
          } 
    }

    if((Get-WebAppPoolState $AppPoolName).Value -eq 'Started')
    {       
        Write-Log "Log - Stopping AppPool..."
        $AllAppPools = Get-Item IIS:\AppPools | dir
        Stop-WebAppPool -Name $AppPoolName 
        # Read the list of app Pool, this cmdlet will till the apppool is ready 
        Write-Log "Log - Waiting for App Pool to Stop ..." 
        $AllAppPools = Get-Item IIS:\AppPools | dir         
        Write-Log "Log -$AppPoolName is Stopped"
    } 
    else 
    { 
        $AllAppPools = Get-Item IIS:\AppPools | dir 
    }
}

Function Remove-FolderFromSitePath(){
    Param([string] $FolderPath, [string] $AplName = "App Pool name Required: To Stop worker process, if files are not deletable", [string] $ExcludeItems = "$false") 
    # Check to see if path is A Folder is removed.Removed, coz some site paths required to preseve the root SITE FOlder"
    if((Test-Path -Path $FolderPath) -eq $True)
    {
        Write-Log "Attempting to Delete Folder and contained items from: $FolderPath"

        $RemoveItemScriptBlockString = "Remove-Item -Path $FolderPath -Force -Recurse -ErrorAction Stop -Verbose"

        if($ExcludeItems) 
        {
            $RemoveItemScriptBlockString = $RemoveItemScriptBlockString + " -Exclude $ExcludeItems" 
        }
                
        try
        {
            # Error action has to be stop, for to be throwing error             
            Invoke-Command -ScriptBlock ([scriptblock]::Create($RemoveItemScriptBlockString))
            Write-Log "Deletion Completed, without errors !" 
            
        }
        catch
        { 
            Write-Log "============================= Error Deleting Files, even after app pool is properly stopped ============================="                        
            
            Write-Log "Force Killing Worker Process in $AplName" 
            Stop-AppPool -AppPoolName $AplName -ForeceKillWorkerProcess $True

            Write-Log "Reading IIS Sites & Appools" 
            $AllSites = Get-Item IIS:\Sites | dir             
            $AllAppPools = Get-Item IIS:\AppPools | dir  

            #Write-Log "Waiting for 30 Seconds" 
            Start-Sleep 5

            Write-Log "Retrying Deletion"             
            Invoke-Command -ScriptBlock ([scriptblock]::Create($RemoveItemScriptBlockString))

            Write-Log "Printing Not Delete Files if any ! " 
            Write-Log (Get-Item $FolderPath -ErrorAction SilentlyContinue| Get-ChildItem -Recurse -ErrorAction SilentlyContinue| Where-Object { !$_.psiscontainer } | Select Directory, Name | fl)                      

        }
        
    }    
}

Function Rename-Configs()
{
    param([string]$Path, [string]$Environment)
    echo "Renaming all webconfigs for Environment $Environment in $Path"

    $FileSreach = "web.$Environment.*"
    $list = Get-ChildItem $Path -filter  $FileSreach –Recurse | group DirectoryName | select Name
    
    foreach($d in $list)
    {
        $fileName = $d.Name+"\web.config" 
        $transformedFileName = $d.Name+"\web.$Environment.config.transformed"
        $nonTransformedFileName = $d.Name+"\web.$Environment.config"

        echo "Searching for files $fileName, $transformedFileName & $nonTransformedFileName"
  
        if((Test-Path $filename) -and (Test-Path $nonTransformedFileName))
        {

            echo "found Non-Transformed $nonTransformedFileName and renaming it..."

           Remove-Item $filename      
           Rename-Item -path $nonTransformedFileName -newname web.config  
           echo "  complete"
        }
    
        if((Test-Path $filename) -and (Test-Path $TransformedFileName))
        {
            echo "found Transformed $transformedFileName and renaming it..."

            Remove-Item $filename    
            Rename-Item -path $transformedFileName -newname web.config 
            echo "  complete" 
        }
    }
    echo " Rename of configs completed"
 }
 
 Function Copy-Recursive
{
    param(
        #Source MUST be an absolute path
        [string]$Source, 
        [string]$Destination, 
        [string[]]$Exclude
    )
    $filePatterns = $Exclude | Where {!([string]$_).StartsWith('\')}
    echo "Patterns:" $filePatterns
    $directoryPatterns = @($Exclude | Where {([string]$_).StartsWith('\')} | %{([string]$_).Substring(1)})
    echo "DirPatterns:" $directoryPatterns    
    Get-ChildItem $Source -Exclude $Exclude | %{
        $path = Join-Path $Destination $_.FullName.Substring($Source.length)
        echo Path: $path        
        if ($_.PSIsContainer)
        {
            if (($directoryPatterns -notmatch $_.Name) -or ($directoryPatterns.Count -eq 0))
            {
			  if (!(Test-Path -path $path))
				{
					New-Item $path -ItemType directory | Out-Null
					echo "Created Folder $Path"
				}               
                Copy-Recursive $_.FullName $path $Exclude
            }
        }
        else
        {
            if (($filePatterns -eq $null) -or (!$filePatterns.Count -gt 0) -or ($filePatterns -notlike $_.Name))
            {
                Copy-Item $_ -Destination $path -Force
                echo "Copied $path"
            }
        }
    }
}



