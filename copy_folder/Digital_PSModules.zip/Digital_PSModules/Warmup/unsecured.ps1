﻿param([bool]$isHttps = $false, [string]$urll = 'www.humana.com',[string]$ipAddress='133.8.2.226', [string]$path = "individual-and-family,medicare", [int]$users = 3, [int]$maxTimeout = 3, [string]$filesToClose = 'C:\Windows\System32\drivers\etc\hosts' )
Import-Module Warmup.psm1
#Determine the protocol
$protocol= "http://"
if($isHttps) { $protocol="https://" }
echo $protocol

#Build Url
$url = $protocol + $urll  
echo $url

Close-OpenFile -filesToClose $filesToClose
HostFileEntry -ipAddress $ipAddress -url $urll
CheckStatusWithTimeout  -url $url -maxTimeout $maxTimeout
HitPagesForUsers -url $url -paths $path -users $users