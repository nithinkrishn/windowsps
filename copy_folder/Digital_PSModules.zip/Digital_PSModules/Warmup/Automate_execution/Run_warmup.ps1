﻿param([string] $UserName = 'HUMAD\kxp0011'<#change#>, [string] $Password ='#######'<#change#>, [string] $urll = 'www.humana.com')
    Remote_Machines = 'lousspwts80','lousspwts247','LOUSSPWTS251';
    serverArguments1 = '133.8.3.127','133.8.2.222','133.8.2.226';
    
}

$count = $servers.Remote_Machines.Count
echo $count




Function Get-ScriptBlock()
{
    Param([string] $ScriptOrPath) 

    # If content ends with .ps1 then script 
    if($ScriptOrPath.EndsWith(".ps1"))
    {
        $ScriptBlock = [scriptblock]::Create((Get-content  -Path $ScriptOrPath -Raw)) 
    }
    else
    {
        $ScriptBlock = [scriptblock]::Create($ScriptOrPath) 
    }
    return $ScriptBlock 
}

for($i=0;$i -lt $count;$i++)
{
$TargetScript = "C:\Users\KXP0011\Desktop\warmupremote\unsecured.ps1"
$ScriptBlock = Get-ScriptBlock -ScriptOrPath $TargetScript 
$SecureString = ConvertTo-SecureString $Password -AsPlainText -Force
$Credentials = New-Object System.Management.Automation.PSCredential($UserName,$SecureString)



$job = Invoke-Command -ComputerName $servers.Remote_Machines[$i]  -ScriptBlock $ScriptBlock -ArgumentList $servers.serverArguments1[$i] -Credential $Credentials -AsJob


$job | Get-Job | Wait-Job
Get-Job | Receive-Job



#echo $output

}

