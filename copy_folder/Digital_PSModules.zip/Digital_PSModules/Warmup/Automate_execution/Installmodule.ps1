﻿param([string] $source = "C:\Users\KXP0011\Desktop\warmupremote\Warmup"<# change this path #>, [string] $dest = "c$\Program Files\WindowsPowerShell\Modules")

$computers = gc "C:\Users\KXP0011\Desktop\warmupremote\machines.txt" <#change this path #>
echo $computers

#Invoke-Command -ComputerName lousspwts251 -Credential HUMAD\kxp0011 -FilePath C:\Users\KXP0011\Desktop\warmupremote\ie.ps1

foreach ($computer in $computers) {
    
    if (test-Connection -Cn $computer -quiet) {
        echo "Installing Module on $computer ................"
        Copy-Item $source -Destination \\$computer\$dest -Recurse -ErrorAction SilentlyContinue
       
    } 
    else 
    {
        "$computer is not online"
    }

}