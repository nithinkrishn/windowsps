﻿Param([string]$env = "",[string]$username = "demomem1",[string]$password = "1234567a",[bool]  $isHttps = $true,[string]$urll = 'www.humana.com',[string]$ipAddress='133.8.2.226',[string]$path = "/members/coverage-claims-spending/",[int]$maxtimeout = 10,[string]$loginPath = '/logon', [string]$filesToClose = 'C:\Windows\System32\drivers\etc\hosts')
 Import-Module Warmup.psm1
 #Determine the protocol
 $protocol = "http://"
 if($isHttps){$protocol = "https://"}
  
 #Build url
 $url = $protocol+$env+''+$urll
  echo $url

Close-OpenFile -filesToClose $filesToClose
HostFileEntry -ipAddress $ipAddress -url $urll
CheckStatusWithTimeout  -url $url -maxTimeout $maxTimeout
Login -loginPath $loginPath -userName $username -passWord $password -url $url
HitPages -url $url -paths $path
