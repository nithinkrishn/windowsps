New-Alias Begin-WebCommitDelay Start-WebCommitDelay
New-Alias End-WebCommitDelay Stop-WebCommitDelay
