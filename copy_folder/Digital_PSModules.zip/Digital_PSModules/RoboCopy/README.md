# RoboCopy is a program that copies documents in parallel!!
RoboCopy performs best when files are  not zipped or compresed. [Read More](https://social.technet.microsoft.com/wiki/contents/articles/1073.robocopy-and-a-few-examples.aspx#Simple_copy)

## Current capabilities
* Copy - copies everything.  This includes folders, subfolder, and any files in them.
* Mirror - This will make source path and destination path contents exactly the same.  Careful! this command will erase any files that are not included in the source path.  This includes folders, subfolder, and any files in them.


Happy coding!