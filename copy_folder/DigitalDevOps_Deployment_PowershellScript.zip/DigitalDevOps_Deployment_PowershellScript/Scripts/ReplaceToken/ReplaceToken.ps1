﻿Param( [string] $KeyValue,[string] $sourcepath, [string] $filename )
 
echo "$KeyValue is key values"
echo  "$filename is filename"
echo "$sourcepath is path of file "

$values = $KeyValue.Split("^|")

echo $values

$count = $values.Count

$configFiles = Get-ChildItem $sourcepath\$filename -Recurse
$j = 0
$k = 1
 
 try
    {
      
       if ($PSVersionTable.PSVersion.Major -eq '2')
        {
          echo "ps version is 2"
          foreach ($file in $configFiles)
          {
           while ($k -le $count)
                {
                    $replace = "__" + $values[$j] + "__"
                    (Get-Content $file) -replace $replace, $values[$k]  | Set-Content $file -Encoding UTF8
                    echo "$file is updated with cookie value"
                    $j=$j+2
                    $k=$k+2
                }  
            $j= 0
            $k = 1
         }
       }

      else
      {
         foreach ($file in $configFiles)
          {
            while ($k -le $count)
                {
                    (Get-Content $file.PSPath).replace("__"+ $values[$j] +"__", $values[$k]) | Set-Content $file.PSPath -Encoding UTF8
                    echo "$file .pspath is updated with cookie value"
                    $j=$j+2
                    $k=$k+2
                }  
            $j= 0
            $k = 1
         }
      }
   }

catch
{
    Write-Output "Log - ERROR"
    Write-Output $_.Exception.Message 
    Write-Output "Log - End of ERROR message"
     
    Write-Host "##vso[task.logissue type=error]deployment has failed. Please follow up with devops "
    Write-Host "##vso[task.complete result=Failed;]"
    write-Host "##vso[task.setvariable variable=DeployResult;]Failed"
    exit 1
}
