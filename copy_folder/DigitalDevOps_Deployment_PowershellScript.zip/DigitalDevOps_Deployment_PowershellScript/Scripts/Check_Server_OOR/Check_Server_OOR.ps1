<# 
.SYNOPSIS
Check Server is OOR
.DESCRIPTION
Powershell script to continue the deployment only if server is OOR
.PARAMETER URLToCheck
$Service - Name of the service 
$NetScaler - Name of Netscalar
$Reason - Usual we give $(Release.ReleaseName)
$Username - username to connect to netscalar
$Password - Password to connect to netscalar
$WaitTime - max wait time in minutes to get response.

.AUTHOR 
Digital DevOps - 10/13/2017
#>
Param($Service,$NetScaler,$Reason,$Username,$Password,$WaitTime,$Url="https://webtech.humana.com/nesservices/api/services",$ServiceState)

Function Credentials([string] $Username,[string] $Password)
{
$P_SS = ConvertTo-SecureString "$Password"  -AsPlainText -Force
$cred= New-Object System.Management.Automation.PSCredential ("$Username", $P_SS)
return $cred
}


Function ServiceStatus([string] $Service,[string] $NetScaler,[string] $Reason,[string] $Username,[string] $Password,[string] $WaitTime)
{
 
 #Body Invoke-restmethod
 $body=@{NetScaler=$NetScaler
         Service=$Service
         Reason=$Reason}
 
 #stop watch
 $timeout = new-timespan -Minutes $WaitTime
 $sw = [diagnostics.stopwatch]::StartNew()
 
 #credentials
 $credentials = Credentials -Username $Username -Password $Password
 
 Do
 {
 echo "checking status of $Service...."
 $resp = Invoke-RestMethod -Uri "$Url/$Service/" -Credential $credentials -Body $body 
 
 if (($ServiceState -eq "DOWN") -and ($resp | Select-String -SimpleMatch '"SvrState":"DOWN"'))
 {
 "$Service is $ServiceState"
 $status = $ServiceState
 }

 if (($ServiceState -eq "UP") -and ($resp | Select-String -SimpleMatch '"SvrState":"UP"'))
 {
 "$Service is $ServiceState"
 $status = $ServiceState
 }

 if (($ServiceState -eq "OUT OF SERVICE") -and ($resp | Select-String -SimpleMatch '"SvrState":"OUT OF SERVICE"'))
 {
 "$Service is $ServiceState"
 $status = $ServiceState
 }
 
 }Until (($sw.elapsed -ge $timeout) -or ($status -eq $ServiceState))
 
 if($sw.elapsed -ge $timeout)
 {
  Write-Error "Server Netscalar Monitoring Error"
 }
}
ServiceStatus -Service $Service -NetScaler $NetScaler -Reason $Reason -Username $Username -Password $Password -WaitTime $WaitTime