﻿Param([String] $directoryName,
[String[]] $Exclude = $null
)



if($Exclude)
{
$ExcludePath = $directoryName +"\"+$Exclude+"*"
(Get-ChildItem "$directoryName" -recurse | select -ExpandProperty fullname) -notlike $ExcludePath | sort length -descending | remove-item -recurse -ErrorAction SilentlyContinue

}

else
{
Remove-Item $directoryName\* -recurse -Force -ErrorAction Stop -verbose
}