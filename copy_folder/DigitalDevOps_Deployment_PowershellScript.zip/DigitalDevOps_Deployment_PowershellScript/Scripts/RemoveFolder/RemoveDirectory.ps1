param([string] $directoryName)
Remove-Item $directoryName\* -recurse -Force -ErrorAction Stop -verbose