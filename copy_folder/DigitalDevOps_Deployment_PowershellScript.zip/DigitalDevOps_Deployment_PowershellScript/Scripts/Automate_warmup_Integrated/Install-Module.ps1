param([string] $source = '\Warmup', [string] $module = 'warmup',[string] $machines = "lousspwts80,lousspwts247,lousspwts250,lousspwts251,lousspwts267,lousspwts268,lousspwts269,lousspwts270,lousspwts271,lousspwts272,lousspwts273")

$location = $MyInvocation.MyCommand.Path

Function Script-Path(){
  $s_path = Split-Path $location
  Write-host "My script directory is $s_path"
  Push-Location $s_path
  return $s_path
}



Function User-Creation(){

   echo "User creation on $computer"
   Invoke-Command -Computername $computer -FilePath ($value + '\usercreation.ps1')

}

Function Install-Module()
 {
   $s = New-PSSession -ComputerName $computer
       
    if(Get-Module -PSSession $s -ListAvailable $module)
    {
      echo "$module exist on $computer"
    }
    else
    {
     echo "$module does not exist on $computer"
     $modulePaths = Invoke-Command -Computername $computer -ScriptBlock { $env:PSModulePath.Split(';'); }
     foreach($Path in $modulePaths)
     {
      echo "Installing Module on $computer ................"
      $Path=$Path -replace "C:", "c$"
      echo $Path
      Copy-Item $source -Destination \\$computer\$Path -Recurse -Force -ErrorAction SilentlyContinue 
     }
    }  
  } 

Function Machine-Status()
 {
    $value = Script-Path
    $source = $value + $source
    echo "source is $source"
    $computers = $machines.Split(',')
    foreach ($computer in $computers) 
    {
     
    if (test-Connection -Cn $computer -quiet) 
    {
     #User-Creation
     Install-Module
    }
    else 
    {
     "$computer is not online"
    }
  }
}
Machine-Status