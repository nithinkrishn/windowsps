Param ([string] $user = 'ddevops', [string] $pass = 'dgtldevops')
$uvalue=net user $user|Select-String -Pattern $user -CaseSensitive -AllMatches | % { $_.Matches } | % { $_.Value } 
echo $uvalue
if ( $uvalue -eq $user) 
{
  echo "user $user already exists"
}

else{ 
echo "user not exists, creating user..."
NET USER $user "$pass" /ADD
NET localgroup Administrators $user /Add 
echo "user $user created"
}