param([string] $url, [string]$path, [string]$env = "", [bool]  $isHttps = $false, [int]$users = 3, [int]$maxTimeout = 10)
Import-Module 'C:\Automate_warmup_Integrated\Warmup'

#Determine the protocol
$protocol = "http://"
if($isHttps){$protocol = "https://"}
echo $protocol

#Build Url
$url = $protocol + $url  
$hfe = $env + '-' + $url
echo $url

CheckStatusWithTimeout  -url $url -maxTimeout $maxTimeout
HitPagesForUsers -url $url -paths $path -users $users