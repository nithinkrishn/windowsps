<# 
.SYNOPSIS
Host File Entry
.DESCRIPTION
Powershell script to perform hostfile entry
.PARAMETER URLToCheck
$Ipaddress - Ip
$Hostname - host
$Action - "add" or "remove" : It performs two actions add and remove the hostfile entry, and also check the ip or hostname conflict before performing any action.

.AUTHOR 
Digital DevOps - 02/26/2018
#>

 param([string] $Ipaddress = "133.8.3.5",[string] $Hostname ="www.hhsfsvs.com", [string] $Action = "add")
  
 $Hostfilelocation = "C:\Windows\System32\drivers\etc\hosts"
 $Pattern1 = '^#'+ "$Ipaddress"+'\W+'+"$Hostname"+'.*'
 $Pattern2 = '^'+ "$Ipaddress"+'\W+'+"$Hostname"+'.*'
 $Suffix = "#DigitalDevops"
 
 #Add host file entry
  function Add-HostFile ([string] $hostfileLocation,[string] $ipAddress,[string] $hostName,[string] $pattern1,[string] $pattern2)
  {

   if((Get-Content $hostfileLocation) -match $pattern1)
   {
   echo "Adding Hostfile $ipAddress $hostName"
   echo "pattern1 $pattern1"

   (Get-Content $hostfileLocation) | Foreach-Object {$_ -replace "$pattern1", "$ipAddress $hostName    $Suffix"} | Set-Content  $hostfileLocation -Encoding Ascii
   }
 
   elseif((Get-Content $hostfileLocation) -match $pattern2 )
   {
     echo "Host file entry $ipAddress $hostName exists"
   }
   
   else 
   {
    echo "Adding new entry $ipAddress $hostName to host file"
    add-content -path $hostfileLocation  -value "`r`n$ipAddress $hostName  $Suffix"
    
   }
  }

  #Remove host file entry
  function Remove-HostFile ([string] $hostfileLocation,[string] $ipAddress,[string] $hostName,[string] $pattern1,[string] $pattern2)
  {
     if((Get-Content $hostfileLocation) -match $pattern1)
     {
      echo "Entry $ipAddress $hostName has been already Removed"
     }
     elseif((Get-Content $hostfileLocation) -match $pattern2)
     {
      echo "Entry found removing $ipAddress $hostName..."
     (Get-Content $hostfileLocation)  -replace ("$pattern2","#$ipAddress  $hostName  $Suffix") | Out-File "$hostfileLocation " -Force ascii
     }
     else
     {
      echo "No such entry found to remove"
     }
   }

   #Check Ip or Hostname Conflict
   function Check-Conflict([string] $hostfileLocation,[string] $ipAddress,[string] $hostName,[string] $action,[string] $pattern1,[string] $pattern2)
   {


     if((-not((Get-Content $hostfileLocation) -match ("^$ipAddress"+'\W+'+"$hostName.*"))) -and ((Get-Content $hostfileLocation) -match "^$ipAddress\W+") -and ((Get-Content $hostfileLocation) -match ("^(?!#).+$hostName.*")))
     {
     echo "there is both ip and hostname conflict"
     }
   
     elseif((-not((Get-Content $hostfileLocation) -match ("^$ipAddress"+'\W+'+"$hostName.*"))) -and ((Get-Content $hostfileLocation) -match ("^(?!#).+$hostName.*")))
     {
      echo "There is hostname conflict"
     }
      
     elseif((-not((Get-Content $hostfileLocation) -match ("^$ipAddress"+'\W+'+"$hostName.*"))) -and ((Get-Content $hostfileLocation) -match "^$ipAddress\W+"))
     {
     echo "there is ip conflict"
     }
     
     else
     {
      echo "Performing $action action...."
      Switch ($action) 
      {
      add {Add-HostFile -hostfileLocation $hostfileLocation -ipAddress $ipAddress -hostName $hostName -pattern1 $pattern1 -pattern2 $pattern2 }
      remove {Remove-HostFile -hostfileLocation $hostfileLocation -ipAddress $ipAddress -hostName $hostName -pattern1 $pattern1 -pattern2 $pattern2  }
      }
     }
   }

Check-Conflict -ipAddress $Ipaddress -hostName $Hostname -action $Action -hostfileLocation $Hostfilelocation -pattern1 $Pattern1 -pattern2 $Pattern2
