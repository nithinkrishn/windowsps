 Param(
[string] $Source
)
$objFolder = $Source + "\obj"
$propertyFolder = $Source + "\Properties"
Remove-Item $objFolder, $propertyFolder -Recurse -ErrorAction SilentlyContinue
Get-ChildItem -Path $Source -Filter "*.pdb" -Recurse -ErrorAction SilentlyContinue | Remove-Item
Get-ChildItem -Path $Source -Filter "*.csproj*" -Recurse -ErrorAction SilentlyContinue | Remove-Item
Get-ChildItem -Path $Source -Filter "*.nupkg" -Recurse -ErrorAction SilentlyContinue | Remove-Item
Get-ChildItem -Path $Source -Filter "*.nuspec" -Recurse -ErrorAction SilentlyContinue | Remove-Item
Get-ChildItem -Path $Source -Filter "Microsoft.IIS.PowerShell.Framework.dll" -Recurse -ErrorAction SilentlyContinue | Remove-Item
Get-ChildItem -Path $Source -Filter "Microsoft.IIS.PowerShell.Provider.dll" -Recurse -ErrorAction SilentlyContinue | Remove-Item
Get-ChildItem -Path $Source -Filter "Hosting.dll" -Recurse -ErrorAction SilentlyContinue | Remove-Item
Get-ChildItem -Path $Source -Filter "Hosting.pdb" -Recurse -ErrorAction SilentlyContinue | Remove-Item