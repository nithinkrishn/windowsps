param([string]$Path, [string]$Environment)

echo "Renaming all webconfigs for Environment $Environment in $Path"

$FileSreach = "web.$Environment.*"

$list = Get-ChildItem $Path -filter  $FileSreach –Recurse | group DirectoryName | select Name

foreach($d in $list)
{
    $fileName = $d.Name+"\web.config" 
    $transformedFileName = $d.Name+"\web.$Environment.config.transformed"
    $nonTransformedFileName = $d.Name+"\web.$Environment.config"

    echo "Searching for files $fileName, $transformedFileName and $nonTransformedFileName"

    if((Test-Path $filename) -and (Test-Path $nonTransformedFileName))
    {

        echo "found Non-Transformed $nonTransformedFileName and renaming it..."

       Remove-Item $filename -Force     
       Rename-Item -path $nonTransformedFileName -newname web.config  -Force
       echo "  complete"
    }

    if((Test-Path $filename) -and (Test-Path $TransformedFileName))
    {
        echo "found Transformed $transformedFileName and renaming it..."

        Remove-Item $filename -Force
        Rename-Item -path $transformedFileName -newname web.config  -Force
        echo "  complete" 
    }
}
echo " Rename of configs completed"