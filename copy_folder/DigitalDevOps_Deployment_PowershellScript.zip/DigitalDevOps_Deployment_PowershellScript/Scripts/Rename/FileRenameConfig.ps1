﻿<#
 .SYNOPSIS
 Changes the name of the source to the target name

.DESCRIPTION
 Takes the parameters of path and sourceName and will rename the sourceName 
 to the targetName

.PARAMETER URLToCheck
 path - path to the directory where the source file is located
 sourceName - name of the file being renamed eg: web.config
 targetName - new name of the source file eg: web.config.old

.AUTHOR
 Digital DevOps - 05/22/2017
 #>

param([string]$path,[string]$sourceName,[string]$targetName)

$global:formattFilePath = "{0}\{1}"
$sourceFile = $global:formattFilePath -f $path, $sourceName


If(Test-Path $sourceFile)
    {
    Rename-Item $sourceFile -NewName $targetName -Force

    Echo "Renamed $sourceFile to $targetName"
    }
else
    {
    Echo "Could not locate file: $sourceFile" 
    }    


