﻿param([string]$Path, [string]$Environment, [string] $RootConfigFile)

echo "Renaming all webconfigs for Environment $Environment in $Path"

$FileSreach = "web.$Environment.*"

#$list = Get-ChildItem $Path -filter  $FileSreach –Recurse | group DirectoryName | select Name
$list = Get-ChildItem -Directory $Path  | Get-ChildItem -filter  $FileSreach –Recurse | group DirectoryName | select Name
remove-item "$Path\Web.config" -Force -ErrorAction SilentlyContinue
Rename-Item "$Path\Web.$RootConfigFile.config.transformed" -newname web.config -Force -ErrorAction SilentlyContinue

if(Test-Path $Path/App_config/Sitecore.$RootConfigFile.config.transformed)
    {
        echo "Renaming Sitecore.$RootConfigFile.config.transformed"
        Remove-item $Path/App_config/Sitecore.config -Force
        Rename-Item -path $Path/App_config/Sitecore.$RootConfigFile.config.transformed -newname $Path/App_config/Sitecore.config -Force
    }

if(Test-Path $Path/cache.xml.transformed)
    {
        echo "Renaming cache.xml.transformed"
        Remove-item $Path/cache.xml -Force
        Rename-Item -path $Path/cache.xml.transformed -newname cache.xml  -Force -ErrorAction SilentlyContinue  -Verbose
    } 
    
foreach($d in $list)
{
    $fileName = $d.Name+"\web.config" 
    $transformedFileName = $d.Name+"\web.$Environment.config.transformed"
    $nonTransformedFileName = $d.Name+"\web.$Environment.config"

    echo "Searching for files $fileName, $transformedFileName and $nonTransformedFileName"

    if((Test-Path $filename) -and (Test-Path $nonTransformedFileName))
    {

        echo "found Non-Transformed $nonTransformedFileName and renaming it..."

       Remove-Item $filename -Force 
       Rename-Item -path $nonTransformedFileName -newname web.config  -Force -ErrorAction SilentlyContinue 
       echo "  complete"
    }

    if((Test-Path $filename) -and (Test-Path $TransformedFileName))
    {
        echo "found Transformed $transformedFileName and renaming it..."

        Remove-Item $filename -Force  
        Rename-Item -path $transformedFileName -newname web.config  -Force -ErrorAction SilentlyContinue 
        echo "  complete" 
    }
}
echo " Rename of configs completed"