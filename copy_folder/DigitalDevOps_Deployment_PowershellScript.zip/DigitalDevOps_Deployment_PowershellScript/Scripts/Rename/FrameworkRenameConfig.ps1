Param([string]$Path, [string] $RootConfigFile)

remove-item "$Path\Web.config" -Force -ErrorAction SilentlyContinue
Rename-Item "$Path\Web.$RootConfigFile.config.transformed" -newname web.config -Force -ErrorAction SilentlyContinue

if(Test-Path $Path/App_config/Sitecore.$RootConfigFile.config.transformed)
    {
        echo "Renaming Sitecore.$RootConfigFile.config.transformed"
        Remove-item $Path/App_config/Sitecore.config -Force
        Rename-Item -path $Path/App_config/Sitecore.$RootConfigFile.config.transformed -newname $Path/App_config/Sitecore.config -Force
    }