﻿param([string] $File = "C:\Users\KXP0011\Desktop\130651.zip", [string] $Destination = "C:\Users\KXP0011\Desktop")

if((Get-ItemProperty -Path "HKLM:\Software\Microsoft\NET Framework Setup\NDP\v4\Full" -ErrorAction SilentlyContinue).Version -like "4.5*" -or 
       (Get-ItemProperty -Path "HKLM:\Software\Microsoft\NET Framework Setup\NDP\v4\Client" -ErrorAction SilentlyContinue).Version -like "4.5*") { 
 
       echo "Attempting to Unzip $File to location $Destination using .NET 4.5" 
        try { 
            [System.Reflection.Assembly]::LoadWithPartialName("System.IO.Compression.FileSystem") | Out-Null 
            [System.IO.Compression.ZipFile]::ExtractToDirectory("$File", "$Destination") 
        } 
        catch { 
            Write-Warning -Message "Unexpected Error. Error details: $_.Exception.Message" 
        } 
 
        }

      
       else { 
 
       echo "Attempting to Unzip $File to location $Destination using COM" 
 
        try { 
            $shell = New-Object -ComObject Shell.Application 
            $shell.Namespace($destination).copyhere(($shell.NameSpace($file)).items()) 
        } 
        catch { 
            Write-Warning -Message "Unexpected Error. Error details: $_.Exception.Message" 
        } 
 
    } 
        
 