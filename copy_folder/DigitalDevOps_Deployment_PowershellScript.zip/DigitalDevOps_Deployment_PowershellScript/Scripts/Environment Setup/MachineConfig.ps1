﻿
 param([string] $SourceMachineConfig = "\\louwebwts131\TfsBuild\machineconfig\machine.config",
      [string] $MachineConfigLocation = "c$\Windows\Microsoft.NET\Framework64\v4.0.30319\Config\machine.config",
      [string] $MachineName = "SIMSSPWDS171")

Function Machine-Configuration([string] $SourceMachineConfig,[string] $MachineConfigLocation,[string] $MachineName)
{
$DestinationMachineConfig = '\\' + $MachineName + '\' + $MachineConfigLocation
if(Compare-Object -ReferenceObject $(Get-Content $SourceMachineConfig) -DifferenceObject $(Get-Content $DestinationMachineConfig))
{
echo "files are different"
Copy-Item -Path $SourceMachineConfig -Destination $DestinationMachineConfig -Force
#Get-Content $SourceMachineConfig -Force -Verbose  | Out-File $DestinationMachineConfig -Verbose -Force
}
Else {"Files are the same"}

}
Machine-Configuration -SourceMachineConfig $SourceMachineConfig -MachineConfigLocation $MachineConfigLocation -MachineName $MachineName