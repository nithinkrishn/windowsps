﻿
param([string] $Module = "WebAdministration",
      [string] $ApppoolName = "int3-drugpricing",
      [string] $SiteName = "int3-drugpricing",
      [string] $Port = 80,
      [string] $PhysicalPath = "D:\HumWeb\docs\humana\DrugPricing3",
      [string] $HostHeader = "int3-drugpricing.humana.com",
      [string] $ApppoolUser = "Wap\IDE_INT",
      [string] $ApppoolPassword = 'vzs2qwr$pyx',
      [string] $Group = "IIS_IUSRS,Performance Monitor Users,Performance Log Users"
     )

      #Enter-PSSession -ComputerName simsspwds170 -Credential Get-Credential
Import-Module -Name $Module

Function Create-FolderStructure([string] $PhysicalPath)
{
 if($PhysicalPath)
 {
 echo "Creating Folder Structure"
 ##Folder Structure
 $split_Paths = $PhysicalPath.Split(",")
 echo ""$split_Paths.Count""
 $i = 0
 for($i -eq 0;$i -lt $split_Paths.Count;$i++){
  New-Item -ItemType Directory -Path $split_Paths[$i] -Force
  }
 }
}

Function Create-AppPool([string] $ApppoolName,[string] $ApppoolUser,[string] $ApppoolPassword)
{
if(Test-Path IIS:\AppPools\$AppPoolName)
{
"AppPool is already there"
}
else
{
echo "Creating Apppool $ApppoolName"
New-WebAppPool $ApppoolName
Set-ItemProperty IIS:\AppPools\$ApppoolName -name processModel -value @{userName=$ApppoolUser;password=$ApppoolPassword;identitytype=3}
}
}

Function Create-Site([string] $SiteName,[string] $ApppoolName,[string] $PhysicalPath,[string] $Port,[string] $HostHeader)
{
if(Test-Path IIS:\Sites\$SiteName)
{
  echo "Site is already there"

}
else
{
echo "Creating Site $SiteName"
New-WebSite -Name $SiteName -Port $Port -HostHeader $HostHeader -PhysicalPath $PhysicalPath -ApplicationPool $ApppoolName
}
}

Function Create-UserGroup([string] $Group,[string] $ApppoolUser)
{
foreach($value in $Group.Split(","))
{

$user = net localgroup $value | Select-String -SimpleMatch $ApppoolUser
echo "user is $user"

if ($ApppoolUser -eq $user)
{
  echo "$ApppoolUser alredy exists in $value"
}

else
{
echo "Adding User $ApppoolUser to the group $value"
net localgroup $value $ApppoolUser /add 
}

}
}

Create-FolderStructure -PhysicalPath $PhysicalPath
Create-AppPool -ApppoolName $ApppoolName -ApppoolUser $ApppoolUser -ApppoolPassword $ApppoolPassword
Create-Site -SiteName $SiteName -ApppoolName $ApppoolName -PhysicalPath $PhysicalPath -Port $Port -HostHeader $HostHeader
Create-UserGroup -Group $Group -ApppoolUser $ApppoolUser
