﻿#Add-LocalGroupMember -Group "Administrators" -Member "HUMAD\TFSReleaseMgr"
try {
    $group = [ADSI]("WinNT://"+$env:COMPUTERNAME+"/administrators,group")
$group.add("WinNT://$env:HUMAD\TFSReleaseMgr,user") 
} catch  {
    echo "HUMAD\TFSReleaseMgr already in administrators"
}