﻿
Param($subscription, $resourceGroup, $location, $tags, $name, $description, $enable,
$condition = "ThresholdRuleCondition", $targetResourceId, $metricName, $operator, $threshold, $windowSize = "PT5M", $timeAggregation, [string] $AzureProductionAppId,
[string] $AzureProductionAppSecret, [string] $tenantId, [string] $subscriptionId)

Function API-Key()
{
 $credential= New-Object -TypeName PSCredential($AzureProductionAppId, (ConvertTo-SecureString -String $AzureProductionAppSecret -AsPlainText -Force))
    $connectParameters = 
    @{
        Credential     = $credential
        TenantId       = $tenantId
        SubscriptionId = $subscriptionId
    }
    
    Add-AzureRmAccount @connectParameters -ServicePrincipal -Verbose

    $resourcegroup
    $tenantId
    $subscriptionId

    return $accountKey = Get-AzureRmStorageAccountKey -ResourceGroupName $resourceGroup -AccountName "dfprodstoragelrseast2" -Verbose
    
}

Function Create-Azure-Alert()
{
    $uri = "https://management.azure.com/subscriptions/$subscription/resourcegroups/$resourceGroup/providers/microsoft.insights/alertrules/chiricutin?api-version=2016-03-01"

    $body = @{
        "Name" = "{   
                    ""location"": ""$location"",
                    ""tags"": {},
                    ""properties"": {
                    ""name"": ""$name"",
                    ""description"": ""$description"",
                    ""isEnabled"": $enable,
                    ""condition"": {
                    ""odata.type"": ""Microsoft.Azure.Management.Insights.Models.$condition"",
                    ""dataSource"": {
                    ""odata.type"": ""Microsoft.Azure.Management.Insights.Models.RuleMetricDataSource"",
                    ""resourceUri"": ""$targetResourceId"",
                    ""metricName"": ""$metricName""
                },
                    ""operator"": $operator,
                    ""threshold"": $threshold,
                    ""windowSize"": ""$windowSize"",
                    ""timeAggregation"": ""$timeAggregation""
                },
                    ""lastUpdatedTime"": ""2016-11-23T21:23:52.0221265Z"",
                    ""actions"": []
                }
                }"
            }

    $body  
    $apiKey = API-Key   
    $apiKey   
    Invoke-RestMethod -Method Post -Uri $uri -Body $body -Verbose -Header @{"X-ApiKey"= $apiKey};
}

Create-Azure-Alert



