﻿param([string] $SourcePath = "\\louwebwts131\TfsBuild\17.06 Backup\HPOC",[string] $DownloadTo = "C:\Build\Stage",[string] $UploadFrom = "C:\Build\Upload", [string] $BucketName = "BuildDrop",[string] $FileName = "*.*")

$Leaf1=$SourcePath.split("\")[-1]
$Leaf2=$SourcePath.split("\")[-2]
$Append = $leaf2 + '_' + $leaf1
echo $Append
$DownloadDirectory = $DownloadTo + '\' + $Append
$ZipFile = $UploadFrom + '\' +$Append + '.zip'
$Key = $Leaf2 + '_' + $Leaf1

function Test-ZipFileExists([string] $ZipFile)
{
echo "Cleaning Folders"
if(Test-Path -Path $ZipFile)
{
echo "Destination already have the zip file $ZipFile"
exit 1
}
}

function Download-File([string] $SourcePath,[string] $DownloadDirectory,[string] $FileName){
for($i = 0; $i -lt 2; $i++) {

if($FileName -ne "*.*")
{
Robocopy $SourcePath $DownloadDirectory $FileName /LEV:1 /E /SEC /R:1 /W:1 /LOG:c:\Robocopylog.txt
} 
elseif($FileName -eq "*.*")
{
Robocopy $SourcePath $DownloadDirectory $FileName /E /SEC /R:1 /W:1 /LOG:c:\Robocopylog.txt
}
}
}

function Upload-ToS3([string] $ZipFile,[string] $DownloadDirectory,[string] $BucketName,[string] $Key){
##zip content
echo "zipping the content to upload to the location $ZipFile"
Add-Type -assembly "system.io.compression.filesystem"

[io.compression.zipfile]::CreateFromDirectory($DownloadDirectory, $ZipFile) 

##Upload to s3
echo "uploading the $ZipFile to the bucket $BucketName"
Write-S3Object -BucketName $BucketName -Key $Key -File $ZipFile -EndpointUrl "http://s3_test.ecs.humana.com:9020" -AccessKey "s3test" -SecretKey "q9S+Sw4n8278RiP2qfK+CV0vYFIfFJzhFQC7de2J"
}

function Clean-AfterUpload([string] $ZipFile)
{
echo "Cleaning the ZipFile $ZipFile"
echo "Cleaning $DownloadDirectory"
Remove-Item -Path $ZipFile -Recurse -ErrorAction SilentlyContinue
Remove-Item -Path $DownloadDirectory -Recurse -ErrorAction SilentlyContinue
}

Test-ZipFileExists -ZipFile $ZipFile
Download-File -SourcePath $SourcePath -DownloadDirectory $DownloadDirectory -FileName $FileName
Upload-ToS3 -ZipFile $ZipFile -DownloadDirectory $DownloadDirectory -BucketName $BucketName -Key $Key 
Clean-AfterUpload -ZipFile $ZipFile