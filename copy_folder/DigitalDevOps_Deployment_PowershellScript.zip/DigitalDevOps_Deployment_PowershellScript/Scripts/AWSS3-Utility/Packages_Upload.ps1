﻿param([string] $SourcePath = "\\louappwts1119\Alphapackage\Web.Areas.Go365Tools",[string] $PackagesUpload = "C:\Package\Upload",[string] $packages = "C:\DownloadPackages",[string] $BucketName = "Digital_KrishnaPemmasani",[string] $key = "test_upload4", [string] $FileName = "*.*")

function Get-PackageContent([string] $SourcePath, [string] $packages,[string] $PackagesUpload)
{
Robocopy $SourcePath $packages  *2.6.1*.nupkg /s  /SEC /R:1 /W:1 /LOG:c:\Robocopylog.txt 
get-childitem $packages -filter *nupkg -recurse | copy-item -Destination $PackagesUpload
}

function Packages-ToUplaod([string] $PackagesUpload,[string] $BucketName,[string] $key)
{
##Upload to s3
$files = Get-ChildItem $PackagesUpload
for ($i=0; $i -lt $files.Count; $i++) {
    $outfile = $files[$i].FullName 
Write-S3Object -BucketName $BucketName -Key $key -File $outfile -EndpointUrl "http://s3_test.ecs.humana.com:9020" -AccessKey "s3test" -SecretKey "q9S+Sw4n8278RiP2qfK+CV0vYFIfFJzhFQC7de2J"
    }
}


function Clean-Packages([string] $packages, [string] $PackagesUpload)
{
echo "cleaning packages"
$clean = $packages + '\' + '*'
$cleanupload = $PackagesUpload + '\' + '*'
Remove-Item $clean, $cleanupload  -recurse -Force -ErrorAction SilentlyContinue
}
Get-PackageContent -SourcePath $SourcePath -packages $packages -PackagesUpload $PackagesUpload
Packages-ToUplaod -PackagesUpload $PackagesUpload -BucketName $BucketName -key $key
Clean-Packages -packages $packages -PackagesUpload $PackagesUpload


##View the bucket content
Get-S3Object -BucketName $BucketName -EndpointUrl "http://s3_test.ecs.humana.com:9020" -AccessKey "s3test" -SecretKey "q9S+Sw4n8278RiP2qfK+CV0vYFIfFJzhFQC7de2J"