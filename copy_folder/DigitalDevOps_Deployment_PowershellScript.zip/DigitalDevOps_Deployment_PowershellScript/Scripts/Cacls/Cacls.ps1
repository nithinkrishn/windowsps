﻿Param(
	[String]$sitePath,
    [String]$drive
)

    $appdata = $sitePath + '\'+"App_Data"
    $temp    = $sitePath + '\'+"temp"  
    $sitecore   = $sitePath +'\'+"sitecore"  
    $data = $sitePath+"-data"
    echo "Directories to create $appdata and $temp"

If($drive -eq 'D')
{

    If(!(test-path $sitePath))
    {
   echo "creating directory $sitePath"
   New-Item -ItemType directory -Force -Path $sitePath
   cacls  $sitePath /e /t /c /g IIS_IUSRS:C
   }
   else{
   echo "$sitePath already exists"
   cacls  $sitePath /e /t /c /g IIS_IUSRS:C
   }

   If(!(test-path $appdata))
    {
   echo "creating directory $appdata"
   New-Item -ItemType directory -Force -Path $appdata
   cacls  $appdata /e /t /c /g IIS_IUSRS:C
   }
   else{
   echo "$appdata already exists"
   cacls  $appdata /e /t /c /g IIS_IUSRS:C
   }
 
   If(!(test-path $temp))
   {
   echo "creating directory $temp"
   New-Item -ItemType directory -Force -Path $temp
   cacls $temp /e /t /c /g IIS_IUSRS:C
   }
   else{
   echo "$temp already exists"
   cacls $temp /e /t /c /g IIS_IUSRS:C
   }

   
   If(!(test-path  $sitecore))
   {
   echo "creating directory  $sitecore"
   New-Item -ItemType directory -Force -Path  $sitecore
   cacls  $sitecore /e /t /c /g IIS_IUSRS:C
   }
   else{
   echo "$sitecore already exists"
   cacls  $sitecore /e /t /c /g IIS_IUSRS:C
   }

   If(!(test-path  $data))
   {
   echo "creating directory  $data"
   New-Item -ItemType directory -Force -Path  $data
   cacls  $data /e /t /c /g IIS_IUSRS:C
   }
   else{
   echo "$data already exists"
   cacls  $data /e /t /c /g IIS_IUSRS:C
   }
   
}

else
{

    If(!(test-path $sitePath))
    {
   echo "creating directory $sitePath"
   New-Item -ItemType directory -Force -Path $sitePath
   cacls  $sitePath /e /t /c /g WebUsers:C
   }
   else{
   echo "$sitePath already exists"
   cacls  $sitePath /e /t /c /g WebUsers:C
   }
    If(!(test-path $appdata))
    {
   echo "creating directory $appdata"
   New-Item -ItemType directory -Force -Path $appdata
   cacls  $appdata /e /t /c /g WebUsers:C
   }
   else{
   echo "$appdata already exists"
   cacls  $appdata /e /t /c /g WebUsers:C
   }
 
   If(!(test-path $temp))
   {
   echo "creating directory $temp"
   New-Item -ItemType directory -Force -Path $temp
   cacls $temp /e /t /c /g WebUsers:C
   }
   else{
   echo "$temp already exists"
   cacls $temp /e /t /c /g WebUsers:C
   }

   
   If(!(test-path  $sitecore))
   {
   echo "creating directory  $sitecore"
   New-Item -ItemType directory -Force -Path  $sitecore
   cacls  $sitecore /e /t /c /g WebUsers:C
   }
   else{
   echo "$sitecore already exists"
   cacls  $sitecore /e /t /c /g WebUsers:C
   }

    If(!(test-path  $data))
   {
   echo "creating directory  $data"
   New-Item -ItemType directory -Force -Path  $data
   cacls  $data /e /t /c /g WebUsers:C
   }
   else{
   echo "$data already exists"
   cacls  $data /e /t /c /g WebUsers:C
   }
   
}