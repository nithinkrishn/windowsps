param([string]$zipFilePath, [string]$outPath)

#$zipFilePath = 'C:\Users\axj0046\Desktop\Test\Hosting.zip';
#$outPath='C:\Users\axj0046\Desktop\Test\unzip\';

If (Test-Path "C:\Windows\Microsoft.NET\Framework\v4.0.30319\System.IO.Compression.FileSystem.dll")
{
    $compressionDllPath= "C:\Windows\Microsoft.NET\Framework\v4.0.30319\System.IO.Compression.FileSystem.dll"
    
    echo $compressionDllPath
}

Add-Type -Path $compressionDllPath

Echo "Deleting contents of the path $outPath"

#Remove-Item $outPath\* -recurse -Force -ErrorAction Stop

#Get-ChildItem -Path $outPath -Recurse | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue

Echo "UnZipping the files from $zipFilePath to $outPath"

[System.IO.Compression.ZipFile]::ExtractToDirectory($zipFilePath,$outPath)