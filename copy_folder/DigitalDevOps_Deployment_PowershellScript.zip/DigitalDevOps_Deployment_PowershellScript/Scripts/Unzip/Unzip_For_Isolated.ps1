Param([string] $FileName, [string] $TargetPath)
 
$cleanDestination = $TargetPath + '\*'
echo "cleaning $TargetPath before unpacking..."
Remove-Item  $cleanDestination  -recurse -force 

$scriptpath = $MyInvocation.MyCommand.Path

$dir = Split-Path $scriptpath

echo "My script directory is $dir"

Push-Location $dir
Import-Module -Name "./1.8.0/7Zip4PowerShell.dll"
Expand-7Zip -TargetPath "$TargetPath" -ArchiveFileName "$FileName" 