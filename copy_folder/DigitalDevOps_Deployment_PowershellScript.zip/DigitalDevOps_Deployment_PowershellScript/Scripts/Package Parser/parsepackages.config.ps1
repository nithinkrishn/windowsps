﻿param ([string] $packageName = "alpha")
If (Get-Content C:\Users\KXP0011\Desktop\packages.config | Select-String -Pattern version=.*$packageName) {
echo "Package Name $packageName Exist"
}
else {
       echo "Package Name $packageName Not Exist"
       Write-Error quiting...
}