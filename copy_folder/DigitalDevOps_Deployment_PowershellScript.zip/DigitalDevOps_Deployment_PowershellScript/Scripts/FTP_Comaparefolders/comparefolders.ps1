<# 
.SYNOPSIS
Powershell Script to compare two ftp folders.

.DESCRIPTION
Downloads ftp folders to local and compares the differences. if it finds differences, it quits the release or else continues the release

.PARAMETER 
$Path1      - "LOUWEBWIS26/humweb/docs/humana/idews/SC8Profile" (path to ftp folder1)
$Path2      - "LOUWEBWDS29/humweb/docs/humana/idews/SC8Profile" (path to ftp folder2)
[string[]]$Excludes - "web.config","*.config","bin" (can give regularexpreessions for file names and foldernames with comma separated and each name should be in double quotes values)
$UserName   - username to connect remote server
$Password   - password to connect remote server
$DownloadTo - "C:\Users\KXP0011\Desktop\New1,C:\Users\KXP0011\Desktop\new2" (Two local paths to dowload the ftp's)
$Module     - required winscp module

.AUTHOR 
Digital DevOps - 05/30/2018
#>

param([string] $Path1 = "LOUWEBWIS26/humweb/docs/humana/idews/SC8Profile",
      [string] $Path2 = "LOUWEBWDS29/humweb/docs/humana/idews/SC8Profile",
      [string[]]$Excludes ,
      [string] $UName = 'Humad\kxp0011',
      [string] $Pwd,
      [string] $DownloadTo = "C:\Users\KXP0011\Desktop\New1,C:\Users\KXP0011\Desktop\new2",
      [string] $WriteOutputToFile = "D:\process.txt", 
      [string] $Module = "WinSCP")
      
      $Path1_Split = $Path1.Split("/")
      $Path1_Split.count
      $servername1 = $Path1_Split[0]
      $DownloadDirectory = $DownloadTo.Split(",")

      for($i = 1;$i -lt $Path1_Split.Count;$i ++)
      {
         $SourcePath1 += $Path1_Split[$i] + '/'
         echo $SourcePath1
      }


      $Path2_Split = $Path2.Split("/")
      $Path2_Split.count
      $servername2 = $Path2_Split[0]

      for($j = 1;$j -lt $Path2_Split.Count;$j ++)
      {
         $SourcePath2 += $Path2_Split[$j] + '/'
         echo $SourcePath2
      }


      echo "servers are $servername1 and $servername2"

      $Servername = "$servername1,$servername2"
      $server_name = $Servername.Split(",")

        echo $server_name.count

        $path = "$SourcePath1,$SourcePath2"
        $sourcepath = $path.Split(",")
    

function Install-WinscpModule([string] $Module)
{
if (Get-Module -ListAvailable -Name $Module) {
    echo "Module exists"
} 
else {
    echo "Module does not exist,installing module"
    Install-Module -Name $Module -Force
}
}


function Download-FromSource()
{
try{
for($k = 0;$k -lt $server_name.Count;$k++)
{
Import-Module -Name WinSCP
$SecureString = ConvertTo-SecureString -AsPlainText $Pwd -Force
$MySecureCreds = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $UName,$SecureString 
$sessionOption = New-WinSCPSessionOption -HostName $server_name[$k] -Credential $MySecureCreds -Protocol Ftp
$winscpsession = New-WinSCPSession -SessionOption $sessionOption
#$winscpsession = New-WinSCPSession -Credential (Get-Credential) -HostName $ServerName -Protocol Ftp
New-Item $DownloadDirectory[$k] -type directory -Force
Sync-WinSCPPath -WinSCPSession $winscpsession -RemotePath $SourcePath[$k] -LocalPath $DownloadDirectory[$k] -Mode Local
Remove-WinSCPSession -WinSCPSession $winscpsession -Verbose

}
}
catch{
        $ErrorMessage = $_.Exception.Message
        echo "error occured $ErrorMessage"
        Exit
        
     }
} 


 
 function compareFolders($folder1,$folder2)
{
 echo "Comparing Folders"
New-Object System.Net.WebClient
$LeftSideHash = Get-ChildItem $folder1 -Recurse -Exclude $Excludes  | Get-FileHash 
$RightSideHash = Get-ChildItem $folder2 -Recurse -Exclude $Excludes | Get-FileHash 

 $foldercontent = (Compare-Object -ReferenceObject $LeftSideHash -DifferenceObject $RightSideHash  -Property hash -PassThru).Path 

 $foldercontent | Out-File -filepath $WriteOutputToFile -Force

IF([string]::IsNullOrEmpty($foldercontent)) {            
    echo "files are same"  
          
} else {            
    
   Write-Error "Terminating the release because files are different: `n$foldercontent"
     
    }
 }

 function Clean-LocalDirectories($folder1, $folder2)
{
  echo "Cleaning Local Directories"
  Remove-Item -Path $folder1 -Recurse -Force -ErrorAction SilentlyContinue
  Remove-Item -Path $folder2 -Recurse -Force -ErrorAction SilentlyContinue
  
}
 Clean-LocalDirectories -folder1 $DownloadDirectory[0] -folder2 $DownloadDirectory[1]
 Install-WinscpModule -Module $Module
 Download-FromSource
 compareFolders -folder1 $DownloadDirectory[0] -folder2 $DownloadDirectory[1]
 
 