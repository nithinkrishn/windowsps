param (
    [string]$Source,
    [string]$Destination,
    [string]$Environment,
    [string]$ExcludeFiles,
    [string]$IncludeFiles
	)
   Remove-Item -Path "$Destination\App_Config", "$Destination\bin", "$Source\Lib\web.config" -Force -Recurse -ErrorAction SilentlyContinue -Verbose
   ROBOCOPY "$Source\Lib" "$Destination\bin\" *.* /S /E /DCOPY:DA /COPY:DAT  /MT /XF $ExcludeFiles /if $IncludeFiles 
   ROBOCOPY "$Source\Lib\App_config" "$Destination\App_config" *.* /S /E /DCOPY:DA /COPY:DAT /MT 
   ROBOCOPY "$Source\Lib\" "$Destination" global.asax /S /E /DCOPY:DA /COPY:DAT /MT 
   Rename-Item -Path "$Source\Lib\web.$Environment.config.Transformed" -NewName "web.config" -Force -ErrorAction SilentlyContinue
   ROBOCOPY "$Source\Lib\" "$Destination" web.config /S /E /DCOPY:DA /COPY:DAT /MT
   if(Test-Path $Destination/App_config/Sitecore.$Environment.config.transformed)
    {
        echo "Renaming Sitecore.$Environment.config.transformed"
        Remove-item $Destination/App_config/Sitecore.config
        Rename-Item -path $Destination/App_config/Sitecore.$Environment.config.transformed -newname $Destination/App_config/Sitecore.config
    }