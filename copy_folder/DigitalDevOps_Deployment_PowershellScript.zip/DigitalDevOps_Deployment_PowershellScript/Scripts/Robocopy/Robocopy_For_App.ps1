﻿Param(
[string] $Source,
[string] $Destination,
[String] $ExcludeDirectories,
[String] $ExcludeFiles
)

#/S	Copy Subdirectories, but not empty ones.
#/E	Copy subdirectories, including Empty ones.
#/V	Produce Verbose output, showing skipped files.
#/DCOPY:T	COPY Directory Timestamps.
#/COPY:copyflag[s]	What to COPY for files (default is /COPY:DAT).(copyflags : D=Data, A=Attributes, T=Timestamps).(S=Security=NTFS ACLs, O=Owner info, U=aUditing info).
#/PURGE	Delete dest files/dirs that no longer exist in source.
#/MIR	MIRror a directory tree (equivalent to /E plus /PURGE).
#/MT[:n]	Do multi-threaded copies with n threads (default 8). n must be at least 1 and not greater than 128. This option is incompatible with the /IPG and /EFSRAW options. Redirect output using /LOG option for better performance.
#/XF file [file]...	eXclude Files matching given names/paths/wildcards.
#/XD dirs [dirs]...	eXclude Directories matching given names/paths.

$objFolder = $Source + "\obj"
$propertyFolder = $Source + "\Properties"
Remove-Item $objFolder, $propertyFolder -Recurse -ErrorAction SilentlyContinue
Remove-Item $Source -Filter *.csproj* -Recurse -ErrorAction SilentlyContinue
Remove-Item $Source -Filter *.nupkg -Recurse -ErrorAction SilentlyContinue
Remove-Item $Source -Filter *.pdb -Recurse -ErrorAction SilentlyContinue
Remove-Item $Source -Filter *.nuspec -Recurse -ErrorAction SilentlyContinue
Remove-Item $Source -Filter "Microsoft.IIS.PowerShell.Framework.dll" -Recurse -ErrorAction SilentlyContinue
Remove-Item $Source -Filter "Microsoft.IIS.PowerShell.Provider.dll" -Recurse -ErrorAction SilentlyContinue
Remove-Item $Source -Filter "Hosting.dll" -Recurse -ErrorAction SilentlyContinue
Remove-Item $Source -Filter "Hosting.pdb" -Recurse -ErrorAction SilentlyContinue

Remove-Item $Destination\ -Recurse -ErrorAction SilentlyContinue

$stringCommand = 'ROBOCOPY *.* ' + $Source + ' ' + $Destination + ' /S /E /DCOPY:T /COPY:DAT /MT'
"*******************Inoking Command*************" + $stringCommand
Invoke-Expression  $stringCommand