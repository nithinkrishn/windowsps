param ($Environment,$Source,$Destination)

    if(Test-Path F:)
    { 
        $RMDirectory = "F:\HumWeb\docs\humana\RM"
    }
    else { 
            $RMDirectory = "D:\HumWeb\docs\humana\RM"
        }
    $InstallationPath = "$RMDirectory\Stage"
    echo "$InstallationPath"
    $BackupDirectory = "$RMDirectory\Backup"
    echo "$BackupDirectory"
    
    #Copy the files     
    if (Test-Path -Path "$Source\App\Hosting")
    {
        ROBOCOPY "$Source\App\Hosting" $InstallationPath Web.$Environment.config.transformed /MT /Purge
 	echo " web config under hosting is deployed in $InstallationPath"
    }   
    if (Test-Path -Path  "$Source\Lib\App_Config")
    {
    ROBOCOPY "$Source\Lib" $InstallationPath Web.$Environment.config.transformed  /MT /Purge
    
	echo " web config under lib for CXM is deployed in $InstallationPath"
    }
    echo "Log - Completing Installtion"
    
    #Renaming Config file
    Rename-Item  $InstallationPath\web.$Environment.config.transformed -newname web.config 

    ##Backup SiteContent
    ROBOCOPY "$Destination" "$BackupDirectory"  web.config  /MT 

   ## Deploying to sitepath
    echo "Deploy config file..."     
    ROBOCOPY "$InstallationPath" "$Destination" web.config /MT 
    echo "...done!"