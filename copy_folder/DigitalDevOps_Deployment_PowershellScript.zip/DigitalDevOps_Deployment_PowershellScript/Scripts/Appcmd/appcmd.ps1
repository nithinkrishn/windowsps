Param(
[string] $Type ="site" , 
[string] $Action = "start", 
[string] $Name = ""
)

if ([string]::IsNullOrEmpty($Name))
{
    echo "Name is required"
}
else

{
   echo "this is elseif 1"
    echo "**********************INPUTS**********************"
    echo "Type: $Type"
    echo "Action: $Action"
    echo "Name: $Name"
    echo "**********************INPUTS**********************"
    $StringCommand = "C:\Windows\System32\inetsrv\appcmd.exe $Action $Type /$Type.name:'$Name'"
    echo "**********************COMMAND**********************"
    echo "Command: $StringCommand"
    echo "**********************COMMAND**********************" 
    $a = iex $StringCommand
if($a -like "*cannot find*")
{
echo "exiting"
  write-error "exiting please check $Name is correct!!!"
}
 }    

  