﻿param([string] $source = '\Warmup', [string] $module = 'warmup',[string] $machines = "lousspwts80,lousspwts247,lousspwts250")

$location = $MyInvocation.MyCommand.Path

Function Script-Path(){
  $s_path = Split-Path $location
  Write-host "My script directory is $s_path"
  Push-Location $s_path
  return $s_path
}

Function Install-Module(){
  $value = Script-Path
  $source = $value + $source
  echo "source is $source"
  #$computers = gc ($value + $machines)
   $computers = $machines.Split(',')
  
  foreach ($computer in $computers) 
  {
    if (test-Connection -Cn $computer -quiet) 
   {
       $s = New-PSSession -ComputerName $computer
       
       if(Get-Module -PSSession $s -ListAvailable $module)
       {
       echo "$module exist on $computer"
       }
       
       else
       {
          echo "$module does not exist on $computer"
          $modulePaths = Invoke-Command -Computername $computer -ScriptBlock { $env:PSModulePath.Split(';'); } 
          foreach($Path in $modulePaths)
          {
           echo "Installing Module on $computer ................"
           $Path=$Path -replace "C:", "c$"
           echo $Path
           Copy-Item $source -Destination \\$computer\$Path -Recurse -ErrorAction SilentlyContinue
           }
        }  
    } 
    else 
    {
        "$computer is not online"
    }
  }
}
Install-Module