param([string] $urll, [string]$path, [string]$env = "", [bool]  $isHttps = $false, [int]$users = 3, [int]$maxTimeout = 10, [string]$filesToClose = 'C:\Windows\System32\drivers\etc\hosts', [string]$defaultpath = "individual-and-family,employer,agent,provider" )
Import-Module 'C:\Program Files\WindowsPowerShell\Modules\Warmup'
$actualPath = $defaultpath + ',' + $path
 #Determine the protocol
 $protocol = "http://"
 if($isHttps){$protocol = "https://"}

echo $protocol

#Build Url
$url = $protocol + $urll  
$hfe = $env + '-' + $urll 
echo $url

#Close-OpenFile -filesToClose $filesToClose -ErrorAction SilentlyContinue
#HostFileEntry -ipAddress $ipAddress -url $urll
CheckStatusWithTimeout  -url $url -maxTimeout $maxTimeout
HitPagesForUsers -url $url -paths $actualPath -users $users