Param([string]$urll, [string]$path, [string]$env = "",[string]$username = "sluser05",[string]$password = "1234567a",[bool]  $isHttps = $true,[int]$maxtimeout = 10,[string]$loginPath = '/logon', [string]$filesToClose = 'C:\Windows\System32\drivers\etc\hosts',[string] $defaultpath = "members/coverage-claims-spending/coverage-benefits,members/coverage-claims-spending/claims,members/contact-us-and-support/documents-forms,members/get-healthy" )
 Import-Module Warmup.psm1
 #Determine the protocol
 $actualPath = $defaultpath + ',' + $path
 $protocol = "http://"
 if($isHttps){$protocol = "https://"}

 #Start-Transcript -Path "D:\transcripts\transcript0.txt" -Append
 #echo "transcript"
  
 #Build url
 $url = $protocol+$urll
  echo $url

#Close-OpenFile -filesToClose $filesToClose
#HostFileEntry -ipAddress $ipAddress -url $urll
CheckStatusWithTimeout  -url $url -maxTimeout $maxTimeout
Login -loginPath $loginPath -userName $username -passWord $password -url $url
HitPages -url $url -paths $actualPath