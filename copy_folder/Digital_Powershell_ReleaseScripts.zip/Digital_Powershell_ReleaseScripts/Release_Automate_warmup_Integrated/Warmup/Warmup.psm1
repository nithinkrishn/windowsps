 Function CheckStatus
{
    param([string]$url)
    try{

    add-type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy

        
        $timeTaken = (Measure-Command -Expression {$response = Invoke-WebRequest -Uri $url}).TotalSeconds
        $seconds = [Math]::Round($timeTaken, 2)
        Write-Host "Response Header - $($response.Headers.ServerName)"
        echo "$url It is up and running Response time is $seconds Seconds, Response is" 
        Return $response.StatusCode 
        }
    catch{
        echo "Validate yourURL"
        exit 1
    }
}

Function CheckStatusWithTimeout
{
    param([string]$url,[int]$maxTimeout)

    $timeout = new-timespan -Seconds $maxTimeout
    $sw = [diagnostics.stopwatch]::StartNew()
    Do
    {
        $responseCode = CheckStatus -url $url
        echo $responseCode
        if( $responseCode -eq "200") { break }
    }while($sw.elapsed -lt $timeout)
}

Function HitPage
{
    param([string]$url, [string] $path)
    $Page = $url + '/' + $Path 
    echo "`nChecking $Page Response....."
    CheckStatus -url $Page
}

Function HitPages
{
    param([string]$url, [string] $paths)

    $PathArray = $paths.Split(",")
    $count = $PathArray.Count

    for($j=0; $j -lt $Count; $j++)
    {
        HitPage -url $url -path $PathArray[$j]
    }
}

Function HitPagesForUsers
{
    param([string]$url, [string] $paths, [int] $users)

    for($j=1; $j -le $users; $j++)
    {
        echo "`nUser $j"
        HitPages -url $url -paths $paths
    }
}

Function Login{

param([string]$loginPath,[string]$userName,[string]$passWord,[string]$url)
    
      CheckStatus -url $url
      $elapsed = [System.Diagnostics.Stopwatch]::StartNew()
      write-host "Started at $(get-date)" 

    Do
    {
    echo doloop

    $site = $url + $loginPath
    $r=Invoke-WebRequest -uri $site -SessionVariable $fb
    $form = $r.Forms[2] 
    $Form | Format-List
    $form.Fields["UserName"] = $userName
    $form.Fields["Password"] = $passWord
    $loginSuccess = $rs.BaseResponse.ResponseUri.AbsolutePath
    $actualValue = "/members/"
    $rs=Invoke-WebRequest -Uri ($url + $form.Action) -WebSession $fb -Method POST -Body $form.Fields -TimeoutSec 780 -ErrorAction SilentlyContinue
    if ($loginSuccess -eq $actualValue)
    {
     echo "Successfully Logged in to $url "
     write-host "Ended at $(get-date)"
      write-host "Time take to login: $($elapsed.Elapsed.Seconds.ToString()) Seconds" 

    }
   
    }
    Until($loginSuccess -eq $actualValue)
    }

function Close-OpenFile {
    Param (
        [String[]]$filesToClose
    )
    Begin {
       
        $netFile = net file
        if($netFile.length -lt 7) { Throw "No Files are Open" }
        echo $($netFile.length)
        $netFile = $netFile[4..($netFile.length-3)]
        $netFile = $netFile | ForEach-Object {
            $column = $_ -split "\s+", 4
            New-Object -Type PSObject -Property @{
                ID = $column[0]
                FilePath = $column[1]
                UserName = $column[2]
                Locks = $column[3]
            }
        }
        $count = 0
    } Process {
        ForEach ($file in $filesToClose) {
            ForEach ($openFile in $netFile) {
                if($openFile.FilePath -eq $file) {
                    $count++
                    net file $openfile.ID /close > $null
                }
            }
        }
    } End { Write-Output "Closed $count Files" }
}


Function HostFileEntry{

 param([string] $ipAddress,[string] $url)
  echo "HostFile entry...."
  #get-content F:\hostfile.txt | select-string -pattern "www.humana.com.+|.+www.humana.com" -notmatch | Out-File F:\hostfile.txt
  (Get-Content -Force "C:\Windows\System32\drivers\etc\hosts") -notmatch $url | ? {$_.trim() -ne "" } | Set-Content -Force "C:\Windows\System32\drivers\etc\hosts"
  Add-Content -Force C:\Windows\System32\drivers\etc\hosts "$ipAddress   $url" 
  echo "Host file entry of $ipAddress and  $url done."
}


 
