param([string] $folders = "\\lousspwts80\D$\FolderA,\\lousspwts80\D$\FolderB",[string] $folder_copy="D:\copy_folderscompare\folderA,D:\copy_folderscompare\folderB")

$folders_split = $folders.Split(",")
$folder_copy_split = $folder_copy.Split(",")
function clean()
{
echo "Cleaning Folders"
$cleanA = $folder_copy_split[0] + '\' + '*'
$cleanB = $folder_copy_split[1] + '\' + '*'
Remove-Item $cleanA -Recurse -Force
Remove-Item $cleanB -Recurse -Force
}

function robo(){
for($i = 0; $i -lt 2; $i++) {
$source = $folders_split[$i]
$destination = $folder_copy_split[$i]
echo $source
echo $destination
Robocopy $source $destination /E /SEC /R:1 /W:1 /LOG:c:\Robocopylog.txt 
}
}

function compareFolders($folder1,$folder2)
{
 echo "Comparing Folders"
New-Object System.Net.WebClient
$LeftSideHash = Get-ChildItem $folder1 -Recurse | Get-FileHash 
#| select @{Label="Path";Expression={$_.Path.Replace($folder1,"")}},Hash
$RightSideHash = Get-ChildItem $folder2 -Recurse | Get-FileHash 
#| select @{Label="Path";Expression={$_.Path.Replace($folder2,"")}},Hash
 Compare-Object $LeftSideHash $RightSideHash -Property Path,Hash | Select-Object path,sideindicator |Out-File D:\output_comparefolders\newcomfile.txt
 Get-Content D:\output_comparefolders\newcomfile.txt
 }
 clean
 robo
 compareFolders -folder1 $folder_copy_split[0] -folder2 $folder_copy_split[1]