param([string] $Path1 = "LOUWEBWIS26/humweb/docs/humana/idews/SC8Profile",
      [string] $Path2 = "LOUWEBWDS29/humweb/docs/humana/idews/SC8Profile",
      [string] $UserName = 'Humad\kxp0011',
      [string] $Password = '',
      [string] $DownloadTo = "C:\Users\KXP0011\Desktop\New folder,C:\Users\KXP0011\Desktop\New folder (2)",
      [string] $Module = "WinSCP")
      
      $Path1_Split = $Path1.Split("/")
      $Path1_Split.count
      $servername1 = $Path1_Split[0]
      $DownloadDirectory = $DownloadTo.Split(",")

      for($i = 1;$i -lt $Path1_Split.Count;$i ++)
      {
         $SourcePath1 += $Path1_Split[$i] + '/'
         echo $SourcePath1
      }


      $Path2_Split = $Path2.Split("/")
      $Path2_Split.count
      $servername2 = $Path2_Split[0]

      for($j = 1;$j -lt $Path2_Split.Count;$j ++)
      {
         $SourcePath2 += $Path2_Split[$j] + '/'
         echo $SourcePath2
      }


      echo "servers are $servername1 and $servername2"

      $Servername = "$servername1,$servername2"
      $server_name = $Servername.Split(",")

        echo $server_name.count

        $path = "$SourcePath1,$SourcePath2"
        $sourcepath = $path.Split(",")
    

function Install-WinscpModule()
{
if (Get-Module -ListAvailable -Name $Module) {
    echo "Module exists"
} 
else {
    echo "Module does not exist,installing module"
    Install-Module -Name $Module -Force
}
}


function Download-FromSource()
{
try{
for($k = 0;$k -lt $server_name.Count;$k++)
{
Import-Module -Name WinSCP
$local:SecureString = ConvertTo-SecureString -AsPlainText $Password -Force
$local:MySecureCreds = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $UserName,$SecureString 
$local:winscpsession = New-WinSCPSession -Credential $MySecureCreds -HostName $server_name[$k] -Protocol Ftp
#$winscpsession = New-WinSCPSession -Credential (Get-Credential) -HostName $ServerName -Protocol Ftp
New-Item $DownloadDirectory[$k] -type directory -Force
Sync-WinSCPPath -WinSCPSession $winscpsession -RemotePath $SourcePath[$k] -LocalPath $DownloadDirectory[$k] -Mode Local 
Remove-WinSCPSession -WinSCPSession $winscpsession -Verbose
}
}
catch{
        $ErrorMessage = $_.Exception.Message
        echo "error occured $ErrorMessage"
        Exit
        
     }
} 

 function compareFolders($folder1,$folder2)
{
 echo "Comparing Folders"
New-Object System.Net.WebClient
$LeftSideHash = Get-ChildItem $folder1 -Recurse | Get-FileHash 
$RightSideHash = Get-ChildItem $folder2 -Recurse | Get-FileHash 
 (Compare-Object -ReferenceObject $LeftSideHash -DifferenceObject $RightSideHash  -Property hash -PassThru).Path 
 }
 Install-WinscpModule
 Download-FromSource
 compareFolders -folder1 $DownloadDirectory[0] -folder2 $DownloadDirectory[1]