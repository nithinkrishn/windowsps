param([string]$source = "C:\ExternalDocs", [string]$destination = "\\lousspwts293\c$\target1,\\lousspwts293\c$\target2", [string]$Type = "mirror")
"Copying from: $source"
"Copy method: $Type"
$dest = $destination.Split(',')
$dest_count = $dest.Count
echo "$dest"
echo "$dest_count"
$i = 0
for($i -eq 0; $i -lt $dest_count; $i++) {
$dest_value = $dest[$i]
echo "Robocopying to destination - $dest_value"
$localjob = Start-Job -ScriptBlock {
 
 param([string] $Type,[string] $source, [string] $destval)
 echo "dest is $dest_val"
 switch($Type)
 {
    "copy"{robocopy $source $destval /MT /V /E /copyall }
    "mirror"{robocopy $source $destval /MT /V /mir /copyall}
 } 
 } -ArgumentList $Type,$source,$dest_value
 } 
 $localjob | Get-Job |Wait-Job
 Get-Job|Receive-Job
 Remove-Job -State Completed 