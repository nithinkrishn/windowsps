﻿param([string]$source, [string]$destination, [string]$Type)
"Copying from: $source"
"Copying to targe: $destination"
"Copy method: $Type"
switch($Type)
{
    "copy"{robocopy $source $destination /MT /V /E /copyall }
    "mirror"{robocopy $source $destination /MT /V /mir /copyall}
}