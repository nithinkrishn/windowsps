param([string] $siteName,[string]$switchPath)

if ( (Get-WindowsFeature -name Web-Server,Web-Scripting-Tools).InstallState -eq "Available,Available")
 {
    
   import-module servermanager
   add-windowsfeature Web-Server,Web-Scripting-Tools
 }

 else {
        "Installed.."
 }

  if ( (Get-WindowsFeature -name Web-Server,Web-Scripting-Tools).InstallState -eq "Installed,Installed")
 {
 echo "switching path of site $siteName"
import-module WebAdministration 
Set-ItemProperty "IIS:\Sites\$siteName" -name physicalPath -value "$switchPath"} 