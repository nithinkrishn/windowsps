﻿param (
[string]$state="",
[string]$append = "",
[string]$apiKey="",
[string]$releaseId,
[string]$application,
[string]$environment,
[string]$instanceA,
[string]$instanceB,
[string]$buildDrop = "\\133.29.6.34\tfsBuild\Build_AB_ReleasePowershellScript\15191\Release_Api\")

echo $state

if ($state -eq 'Start')
{
$urlStart = "https://dev-adt.qa-cf.humana.com/DeploymentStarted/$releaseId/$application/$environment/$instanceA/$instanceB"
echo $urlStart
$Result = Invoke-RestMethod -Method Post -Uri $urlStart -Header @{ "X-ApiKey" = $apiKey }
$Final_Result = $Result + $append
}


if ($state -eq 'End')
{
 $urlEnd = "https://dev-adt.qa-cf.humana.com/DeploymentCompleted/$releaseId/$application/$environment/$instanceA/$instanceB"
 echo $urlEnd
 $Result = Invoke-RestMethod -Method Post -Uri $urlEnd -Header @{ "X-ApiKey" = $apiKey } 
 $Final_Result = $Result + $append
}
echo "Result of api $Final_Result"
$Final_Result | Out-File D:\AB\ReleaseID.txt -Force
Copy-Item D:\AB\ReleaseID.txt -Destination $buildDrop -Recurse -Force
#[Environment]::SetEnvironmentVariable("Api_Result", "$Final_Result", "Machine")
