﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TfsBuildDashboard.Services;
using TfsFailedBuildBatch.Models;
using TfsFailedBuildBatch.DBActions;
using System.Net.Mail;

namespace TfsFailedBuildBatch
{
    class Program
    {
        static void Main(string[] args)
        {
            UpdateFailedBuilds();
        }

        private static void SendMail()
        {
            throw new NotImplementedException();
        }

        private static void UpdateFailedBuilds()
        {
            var easternZone = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
            string startDate = DateTime.Now.AddHours(5).AddDays(-1).ToString();
            string endDate = DateTime.Now.AddHours(5).ToString();
            RestClient rClient = new RestClient();
            rClient.endPoint = "https://tfs.humana.com/tfs/DefaultCollection/IDE/_apis/build/builds?minFinishTime=" + startDate + "&maxFinishTime=" + endDate + "&api-version=2.0";
            string strResponse = string.Empty;
            strResponse = rClient.makeRequest();

            var model = Newtonsoft.Json.JsonConvert.DeserializeObject<BuildModel>(strResponse);
           
            var distinctBuilds1 =           model.Value
                                          .GroupBy(build => build.Definition.Name)
                                          .Select(g => g)
                                          .ToList();

            var result1 = (from x in distinctBuilds1
                           select new
                           {
                               Key = x.Key,
                               values = x.ToList()
                           }).ToList();

            foreach (var res in result1)
            {
                var temp = res.values.Where(z => z.result =="failed").ToList();
                if (temp != null & temp.Count > 0)
                {
                    string Message = GetMessage(temp.LastOrDefault().logs);

                    
                    res.values.ForEach(x => x.LastFailedLogMessage = Message);
              
                }

                var temp2 = res.values.ToList();
                if (temp2 != null & temp2.Count > 0)
                {
                    
                    string TName = GetTeamName(temp2.LastOrDefault().Definition);
                    string AName = GetAppName(temp2.LastOrDefault().Definition);
                    string Author = AuthorInfo(temp2.LastOrDefault().Definition);
                    res.values.ForEach(x => x.Author = Author);
                    res.values.ForEach(x => x.TName = TName);
                    res.values.ForEach(x => x.AName = AName);
                }

            }

            List<Value> distinctBuilds = model.Value
                                            .GroupBy(build => build.Definition.Name)
                                            .Select(g => g.First())
                                            .ToList();


            using (TfsBuildDataContext dc = new TfsBuildDataContext())
            {
                List<FailedBuild> failedBuilds = (from db in result1
                                                  select new FailedBuild
                                                  {
                                                      BuildName = db.Key,
                                                      BuildUrl = "https://tfs.humana.com/tfs/DefaultCollection/IDE/_build/index?definitionId=" + db.values.FirstOrDefault().Definition.Id,
                                                      Date = TimeZoneInfo.ConvertTimeFromUtc(db.values.Last().finishTime, easternZone).Date,
                                                      Time = TimeZoneInfo.ConvertTimeFromUtc(db.values.Last().finishTime, easternZone).TimeOfDay,                                                     
                                                      TotalBuilds = db.values.Count,
                                                      SucceededBuilds = db.values.Where(x => x.result.ToLower().Contains("succeeded")).Count(),
                                                      FailedBuilds = db.values.Where(x => x.result.ToLower() == "failed").Count(),
                                                      FailedReason = db.values.FirstOrDefault().LastFailedLogMessage,
                                                    Author = db.values.FirstOrDefault().Author,
                                                      TeamName = db.values.FirstOrDefault().TName,
                                                      AppName = db.values.FirstOrDefault().AName
                                                  }).ToList();

                List<string> emailIds = (from e in dc.EmailDetails select e.EmailId).ToList();
                dc.FailedBuilds.InsertAllOnSubmit(failedBuilds);
                dc.SubmitChanges();
                SendMail(failedBuilds, emailIds);
            }



          
        }

        private static string AuthorInfo(Definition def)
        {
            RestClient rClient = new RestClient();
            rClient.endPoint = def.Url;
            string strResponse = string.Empty;
            strResponse = rClient.makeRequest();
            var model = Newtonsoft.Json.JsonConvert.DeserializeObject<AuthorInfo>(strResponse);
            return model.authoredBy.displayName;
        }

        private static string GetTeamName(Definition def)
        {
            RestClient rClient = new RestClient();
            rClient.endPoint = def.Url;
            string strResponse = string.Empty;
            strResponse = rClient.makeRequest();
            var model = Newtonsoft.Json.JsonConvert.DeserializeObject<TeamNames>(strResponse);
            strResponse = string.Empty;
            return model.variables.TeamName.value;
        }

        private static string GetAppName(Definition def)
        {
            RestClient rClient = new RestClient();
            rClient.endPoint = def.Url;
            string strResponse = string.Empty;
            strResponse = rClient.makeRequest();
            var model = Newtonsoft.Json.JsonConvert.DeserializeObject<TeamNames>(strResponse);
            strResponse = string.Empty;
            return model.variables.AppName.value;
        }

        private static string GetMessage(Log log)
        {
            RestClient rClient = new RestClient();
            rClient.endPoint = log.url;
            string strResponse = string.Empty;
            strResponse = rClient.makeRequest();

            var model = Newtonsoft.Json.JsonConvert.DeserializeObject<LogMessage>(strResponse);
            strResponse = string.Empty;
           
                foreach (var item in model.value)
                {
                    rClient.endPoint = item.url;
                    strResponse += rClient.makeRequest();
                }
          
             if (strResponse.ToLower().Contains("there is an error in xml document"))
            {

                return "Source Issue-ALM";
               
            }

             else if (strResponse.ToLower().Contains("unable to find version"))
             {

                 return "Nuget Version Issue-Dev";

             }

             else if (strResponse.ToLower().Contains("sonarscanner.msbuild.exe failed"))
             {

                 return "Code Analysis-Dev";

             }

             else if (strResponse.ToLower().Contains("versionassemblyinfo.ps1' is not recognized as the name of a cmdlet"))
             {

                 return "Vesion Assemblies-Dev";

             }

             else if (strResponse.ToLower().Contains("could not copy the file"))
             {

                 return "Code Issue-Dev";

             }
             
            else if (strResponse.ToLower().Contains("'msbuild.exe' exited"))
            {
                return "Code Issue-Dev";
            }
            
            else if (strResponse.ToLower().Contains("packages failed to install"))
            {
                return "Nuget Restore-ALM";
            }

             else if (strResponse.ToLower().Contains("exit code 100 returned from process"))
            {
                return "Source Issue-ALM";
            }

             else if (strResponse.ToLower().Contains("npm failed with error"))
            {
                return "Npm Issue-ALM or EnterPriseDevops";

            }
           
             else if (strResponse.ToLower().Contains("sonarqube server is not compatible with the sonarqube analysis agent"))
            {
                return "SonarQube Issue-ALM or EnterPriseDevops";

            }
             else if (strResponse.ToLower().Contains("vstest test run failed"))
            {
                return "TestAssembly Issue-Dev";

            }

                 
                 
             else 
             {
                 return "UnidentifiedIssue-";

             } 
           
        }

        private static void SendMail(List<FailedBuild> failedBuilds, List<string> emailIds)
        {

            int TotalBuilds = failedBuilds.Sum(x => x.TotalBuilds);
            int TotalSucceeded = failedBuilds.Sum(x => x.SucceededBuilds);
            int TotalFailed = failedBuilds.Sum(x => x.FailedBuilds);

            StringBuilder htmlBody = new StringBuilder();


            htmlBody.Append(" <style type=\"text/css\">.TFtable{width:60%;border-collapse:collapse;}.TFtable td{ padding:7px; border:#013883 1px solid;}.TFtable tr{background: #80d4ff;}.TFtable tr:nth-child(odd){ background: #80d4ff;}.TFtable tr:nth-child(even){	background: #FFA08C;}</style>");


            htmlBody.Append("<h2>Total Builds : " + TotalBuilds + "  |  Failed Builds : " + TotalFailed + "</h2>");


            htmlBody.Append("<table class=\"TFtable\"><tr><td><b> S.No </b></td><td><b>Build Name</b></td><td><b>Total Builds</b></td><td><b>Succeeded Builds</b></td><td><b>Failed Builds</b></td><td><b>Failed Reason</b></td><td><b>Ownership</b></td> <td><b>TeamName</b></td> <td><b>AppName</b></td> <td><b>Author</b></td> <td><b>Last Build DateTime</b></td></tr>");
           int i = 1;
            foreach (var failedBuild in failedBuilds)
            {
                 List<string> owners = new List<string>();
                if (!string.IsNullOrEmpty(failedBuild.FailedReason))
                {
                    owners = failedBuild.FailedReason.Split('-').ToList();
                  
                }
                else
                {
                    owners.Add(" ");
                    owners.Add(" ");
                }
                htmlBody.Append("<tr>");
                if (failedBuild.SucceededBuilds == 0)
                    htmlBody.Append(@"<td>" + i.ToString() + "</td><td ><a href=\"" + failedBuild.BuildUrl + "\"target=\"_blank\"><p style=\"color:red;\" >" + failedBuild.BuildName + "</p></a></td><td>" + failedBuild.TotalBuilds + "</td><td style=\"color:green;\">" + failedBuild.SucceededBuilds + "</td><td style=\"color:red;\">" + failedBuild.FailedBuilds + "</td><td style=\"color:red;\">" + owners[0] + "</td><td style=\"color:red;\">" + owners[1] + "</td><td style=\"color:green;\">" + failedBuild.TeamName + "</td> <td style=\"color:green;\">" + failedBuild.AppName + "</td> <td style=\"color:green;\">" + failedBuild.Author + "</td><td>" + failedBuild.Date.ToString("yyyy-MM-ddTHH:mm") + "</td>");
                else
                    htmlBody.Append(@"<td>" + i.ToString() + "</td><td ><a href=\"" + failedBuild.BuildUrl + "\"target=\"_blank\"><p style=\"color:green;\" >" + failedBuild.BuildName + "</p></a></td><td>" + failedBuild.TotalBuilds + "</td><td style=\"color:green;\">" + failedBuild.SucceededBuilds + "</td><td style=\"color:red;\">" + failedBuild.FailedBuilds + "</td><td style=\"color:red;\">" + owners[0] + "</td><td style=\"color:red;\">" + owners[1] + "</td><td style=\"color:green;\">" + failedBuild.TeamName + "</td> <td style=\"color:green;\">" + failedBuild.AppName + "</td> <td style=\"color:green;\">" + failedBuild.Author + "</td><td>" + failedBuild.Date.ToString("yyyy-MM-ddTHH:mm") + "</td>");

                htmlBody.Append("</tr>");
                i++;
            }
            htmlBody.Append("</table>");
            string startDate = DateTime.Now.AddDays(-1).ToShortDateString();
            string endDate = DateTime.Now.ToShortDateString();

           // bool isMailSent = SendMail("8593330044@txt.att.net", "Build Status - " + startDate + " - " + endDate, htmlBody.ToString());
            bool isMailSent = SendMail(emailIds, "Build Status - " + startDate + " - " + endDate, htmlBody.ToString());
        }

        private static bool SendMail(List<string> emailIds, string subject, string body)
        {
            try
            {
                var mail = new MailMessage();
                var smtpServer = new SmtpClient("pobox.Humana.com");
                smtpServer.Port = 25;
                smtpServer.EnableSsl = false;

                mail.From = new MailAddress("pobox@humana.com");
                foreach (var emailId in emailIds)
                {
                    mail.To.Add(emailId);
                }
                mail.Subject = subject;
                mail.IsBodyHtml = true;
                mail.Body = body;
                //body = body.Substring(0, body.LastIndexOf("-"));
                //mail.Body = body.Replace("<br>", "").Replace("<p>", "").Replace("</p>", "").Replace("<b>", "").Replace("</b>", "").Replace("------------------------", "").Replace("\">Link to Issue</a>", "").Replace("<a href=\"", "");
                //mail.Body = "<a href=\"https://tfs.humana.com/tfs/DefaultCollection2/DigitalDevOps/_workitems?id=98073&fullScreen=true&_a=edit\">Additional Information</a></div><div><p><b>Maintenance Issue:</b> <br>Decommission  the server</p><p><br><b>User Description:</b><br>test</p></div><div><br>-------------------------<br>Requestor: Thomas V Nelson<br><b>Email:</b> <a href=\"mailto:TNelson8@humana.com\">TNelson8@humana.com</a><br>Phone: 0</div></body></html>";
                //mail.Body = "<html xmlns:v=\"urn:schemas-microsoft-com:vml\"xmlns:o=\"urn:schemas-microsoft-com:office:office\"xmlns:w=\"urn:schemas-microsoft-com:office:word\"xmlns:m=\"http://schemas.microsoft.com/office/2004/12/omml\"xmlns=\"http://www.w3.org/TR/REC-html40\"><table align=\"center\" border=\"1\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\"><tr><td bgcolor=\"#70bbd9\">Row 1</td></tr><tr><td bgcolor=\"#ffffff\">Row 2</td></tr><tr><td bgcolor=\"#ee4c50\">Row 3</td></tr></table></html>";
                smtpServer.Send(mail);

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}
