﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TfsFailedBuildBatch.Models
{
    [Serializable]
    public class BuildModel
    {
        public int Count { get; set; }

        public List<Value> Value { get; set; }
    }

    [Serializable]
    public class Value
    {
        public List<ValidationResult> validationResults { get; set; }

        public List<Plan> Plans { get; set; }

        public long id { get; set; }

        public string buildNumber { get; set; }

        public Definition Definition { get; set; }

        public DateTime finishTime { get; set; }

        public string result { get; set; }

        public Log logs { get; set; }

        public string LastFailedLogMessage { get; set; }

        public string Author { get; set; }
        public string TName { get; set; }
        public string AName { get; set; }


    }

    [Serializable]
    public class Log
    {
        public string url { get; set; }
    }

    [Serializable]
    public class ValidationResult
    {
        public string result { get; set; }
    }

    [Serializable]
    public class Plan
    {
        public string startTime { get; set; }
    }

    [Serializable]
    public class Definition
    {
        public string Id { get; set; }

        public string Name { get; set; }

        public string BuildUrl { get; set; }

        public string Url { get; set; }

        public Definition()
        {
            BuildUrl = "https://tfs.humana.com/tfs/DefaultCollection/IDE/_build/index?definitionId=";
        }
    }

    [Serializable]
    public class LogMessage
    {
        public int count { get; set; }

        public List<LogValue> value { get; set; }
    }

    [Serializable]
    public class LogValue
    {
        public  string url { get; set; }
    }

    [Serializable]
    public class AuthorInfo
    {
        public AuthoredBy authoredBy { get; set; }
    }
    public class AuthoredBy
    {
        public string displayName { get; set; }
    }

    [Serializable]
    public class TeamNames
    {
        public Variables variables { get; set; }
    }
    public class Variables
    {
        public TeamName TeamName { get; set; }
        public AppName AppName { get; set; }
    }
    public class TeamName
    {
        public string value { get; set; }
    }

    public class AppName
    {
        public string value { get; set; }
    }

}